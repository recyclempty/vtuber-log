var tweet_index =  [ {
  "file_name" : "data\/js\/tweets\/2019_02.js",
  "year" : 2019,
  "var_name" : "tweets_2019_02",
  "tweet_count" : 12,
  "month" : 2
}, {
  "file_name" : "data\/js\/tweets\/2019_01.js",
  "year" : 2019,
  "var_name" : "tweets_2019_01",
  "tweet_count" : 26,
  "month" : 1
}, {
  "file_name" : "data\/js\/tweets\/2018_12.js",
  "year" : 2018,
  "var_name" : "tweets_2018_12",
  "tweet_count" : 45,
  "month" : 12
}, {
  "file_name" : "data\/js\/tweets\/2018_11.js",
  "year" : 2018,
  "var_name" : "tweets_2018_11",
  "tweet_count" : 44,
  "month" : 11
}, {
  "file_name" : "data\/js\/tweets\/2018_10.js",
  "year" : 2018,
  "var_name" : "tweets_2018_10",
  "tweet_count" : 15,
  "month" : 10
} ]