Grailbird.data.tweets_2018_10 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 65, 88 ],
      "url" : "https:\/\/t.co\/ZHTtRGcL0L",
      "expanded_url" : "https:\/\/github.com\/recyclempty\/vtuber-log",
      "display_url" : "github.com\/recyclempty\/vt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1057228266010947585",
  "text" : "\u30EC\u30DD\u30FC\u30C8\u3092\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3057\u307E\u3057\u305F\n\u9045\u304F\u306A\u3063\u3066\u3059\u307F\u307E\u305B\u3093\n\u8272\u3005\u7269\u3092\u8A66\u3057\u3066\u3001\u6642\u9593\u304C\u304B\u304B\u308A\u3059\u304E\u307E\u3059\uD83D\uDCA6\n\n\u4ECA\u5F8C\u306E\u8CC7\u6599\u3082\u3053\u3053\u306B\u4FDD\u5B58\u3055\u308C\u307E\u3059\n\nhttps:\/\/t.co\/ZHTtRGcL0L",
  "id" : 1057228266010947585,
  "created_at" : "2018-10-30 11:10:35 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1056234789294956544",
  "text" : "\u4ECA\u9031\u306E\u5831\u544A\u7D42\u308F\u308A\u307E\u3057\u305F\n\u898B\u3066\u304F\u308C\u3066\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\n\u6B21\u306F\u4ECA\u56DE\u3088\u308A\u3082\u3063\u3068\u7DF4\u7FD2\u3059\u308B\n\n\u3042\u3068\u3001\u6BCE\u9031\u5831\u544A\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u306E\u5834\u6240\u3092\u63A2\u3057\u3066",
  "id" : 1056234789294956544,
  "created_at" : "2018-10-27 17:22:52 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vtuber",
      "indices" : [ 124, 131 ]
    } ],
    "urls" : [ {
      "indices" : [ 99, 122 ],
      "url" : "https:\/\/t.co\/ide0DblKUg",
      "expanded_url" : "https:\/\/www.youtube.com\/channel\/UC2F8FM_lVc-s32-XTE1y0iw\/live",
      "display_url" : "youtube.com\/channel\/UC2F8F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1056166553819856897",
  "text" : "\u4ECA\u591C25\u6642\u304B\u3089\u5831\u544A\u3059\u308B\u3001\u5185\u5BB9\u306F\u4EE5\u4E0B\n1. OBS\u3067\u97F3\u58F0\u30D5\u30A3\u30EB\u30BF\u306E\u8A2D\u5B9A\n2. FaceRig\u3067\u8907\u6570\u30A2\u30D0\u30BF\u30FC\u6A5F\u80FD\n3. youtube\u306E\u52D5\u753B\u306B\u5B57\u5E55\u3092\u8FFD\u52A0\u3059\u308B\n\n\u4E88\u60F3\u6642\u9593\u304C10\u5206\u3001\u3082\u3057\u8208\u5473\u304C\u3042\u308C\u3070\u3053\u3061\u3089\nhttps:\/\/t.co\/ide0DblKUg\n\n#Vtuber",
  "id" : 1056166553819856897,
  "created_at" : "2018-10-27 12:51:43 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/8CNXvau5wv",
      "expanded_url" : "http:\/\/forum.live2d.com\/discussion\/1210",
      "display_url" : "forum.live2d.com\/discussion\/1210"
    } ]
  },
  "in_reply_to_status_id_str" : "1055530367564697601",
  "geo" : { },
  "id_str" : "1055530372350394369",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u6B8B\u5FF5\u306A\u3053\u3068\u306B\nCPU\u4F7F\u7528\u7387\u304C\u9AD8\u304F\u306A\u308B\nFaceRig\u3067\u306ELive2D\u306E\u8907\u6570\u30A2\u30D0\u30BF\u30FC\u6A5F\u80FD\u306F\u30D0\u30B0\u3042\u308B\n\u305F\u3076\u3093\u4F7F\u308F\u306A\u3044\n\n\u30D0\u30B0\u306E\u8A73\u3057\u3044\u3053\u3061\u3089\nhttps:\/\/t.co\/8CNXvau5wv",
  "id" : 1055530372350394369,
  "in_reply_to_status_id" : 1055530367564697601,
  "created_at" : "2018-10-25 18:43:46 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/kENCcmy0gQ",
      "expanded_url" : "https:\/\/drive.google.com\/open?id=1q9twthzpO2sbUDnZJyzlJ-i2KSXWWjFh",
      "display_url" : "drive.google.com\/open?id=1q9twt\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "1055530372350394369",
  "geo" : { },
  "id_str" : "1055530374019731456",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u3042\u3068\u3001\u304B\u307C\u3061\u3083\u3092\u30A2\u30C3\u30D7\u3057\u305F\u3001\u3054\u81EA\u7531\u306B\u304A\u4F7F\u3044\u4E0B\u3055\u3044\nhttps:\/\/t.co\/kENCcmy0gQ",
  "id" : 1055530374019731456,
  "in_reply_to_status_id" : 1055530372350394369,
  "created_at" : "2018-10-25 18:43:46 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1055530367564697601\/video\/1",
      "indices" : [ 35, 58 ],
      "url" : "https:\/\/t.co\/sEGBKI2oBe",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1055518213491118082\/pu\/img\/U2JT-sQRrGF3Emoa.jpg",
      "id_str" : "1055518213491118082",
      "id" : 1055518213491118082,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1055518213491118082\/pu\/img\/U2JT-sQRrGF3Emoa.jpg",
      "sizes" : [ {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/sEGBKI2oBe"
    } ],
    "hashtags" : [ {
      "text" : "VTuber",
      "indices" : [ 10, 17 ]
    }, {
      "text" : "Live2D",
      "indices" : [ 18, 25 ]
    }, {
      "text" : "FaceRig",
      "indices" : [ 26, 34 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1055530367564697601",
  "text" : "\u30CF\u30ED\u30A6\u30A3\u30F3\u304B\u307C\u3061\u3083\n#VTuber #Live2D #FaceRig https:\/\/t.co\/sEGBKI2oBe",
  "id" : 1055530367564697601,
  "created_at" : "2018-10-25 18:43:45 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/0lOsjL7ZtU",
      "expanded_url" : "http:\/\/sloppy-games.com\/obs-studio%E3%81%A7%E3%82%B2%E3%83%BC%E3%83%A0%E5%AE%9F%E6%B3%81%EF%BC%81%E3%82%AB%E3%82%AF%E3%82%AB%E3%82%AF%E3%82%82%E9%9F%B3%E5%89%B2%E3%82%8C%E3%82%82%E3%81%95%E3%82%88%E3%81%86%E3%81%AA%E3%82%89\/",
      "display_url" : "sloppy-games.com\/obs-studio%E3%\u2026"
    } ]
  },
  "in_reply_to_status_id_str" : "1054725130352349184",
  "geo" : { },
  "id_str" : "1054725132177080321",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u307E\u3060\u4F55\u304B\u8DB3\u308A\u306A\u3044......\u3084\u3063\u3071\u308A\u74B0\u5883\u6539\u5584\u3057\u304B\u306A\u3044\n\n\u3053\u3061\u306F\u7D50\u69CB\u53C2\u8003\u306B\u306A\u308B\nhttps:\/\/t.co\/0lOsjL7ZtU",
  "id" : 1054725132177080321,
  "in_reply_to_status_id" : 1054725130352349184,
  "created_at" : "2018-10-23 13:24:02 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1054725130352349184",
  "text" : "\u306A\u3093\u304B\u3001\u97F3\u8CEA\u6539\u5584\u3092\u3046\u307E\u304F\u3044\u304B\u306A\u3044\n\u300C\u30CE\u30A4\u30BA\u5236\u6291\u300D\u30CE\u30A4\u30BA\u3092\u5C0F\u3055\u304F\u3059\u308B\n\u300C\u30B2\u30A4\u30F3\u300D\u97F3\u91CF\u3092\u5927\u304D\u304F\u3059\u308B\u3068\u5C0F\u3055\u304F\u3059\u308B\n\u300C\u30CE\u30A4\u30BA\u30B2\u30FC\u30C8\u300D\u97F3\u91CF\u304C\u5C0F\u3055\u3044\u6642\u306F\u5B8C\u5168\u306B\u5165\u529B\u3057\u306A\u3044\n\u300C\u30B3\u30F3\u30D7\u30EC\u30C3\u30B5\u30FC\u300D\u97F3\u91CF\u3092\u4E00\u5B9A\u306B\u3059\u308B\u305F\u3081(\u81EA\u5206\u306E\u7406\u89E3\u306F\u97F3\u58F0\u4F53\u7A4D\u306E\u30B3\u30F3\u30C8\u30ED\u30FC\u30EB)\n\u300C\u30A4\u30B3\u30E9\u30A4\u30B6\u30FC\u300D\u7279\u5B9A\u306E\u97F3\u58F0\u5E2F\u57DF\u306E\u97F3\u91CF\u3092\u8ABF\u6574\u3059\u308B",
  "id" : 1054725130352349184,
  "created_at" : "2018-10-23 13:24:01 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vtuber\u306F\u3058\u3081\u307E\u3057\u305F",
      "indices" : [ 39, 52 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1054104512787492864",
  "text" : "\u3053\u308C\u304B\u3089\u30C4\u30A4\u30C3\u30BF\u30FC\u6D3B\u52D5\u958B\u59CB\n\u57FA\u672C\u306F\u81EA\u5206\u306E\u30C7\u30FC\u30BF\u30ED\u30B0\u3001\u304A\u5F79\u306B\u7ACB\u3066\u308C\u3070\u5B09\u3057\u3044\u3067\u3059\n#Vtuber\u306F\u3058\u3081\u307E\u3057\u305F",
  "id" : 1054104512787492864,
  "created_at" : "2018-10-21 20:17:54 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1054055280651071488\/video\/1",
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/tm7TFB3zdk",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1054053511934050304\/pu\/img\/aNHXaS0Ml5f9E2TC.jpg",
      "id_str" : "1054053511934050304",
      "id" : 1054053511934050304,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1054053511934050304\/pu\/img\/aNHXaS0Ml5f9E2TC.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/tm7TFB3zdk"
    } ],
    "hashtags" : [ {
      "text" : "Vtuber\u6E96\u5099\u4E2D",
      "indices" : [ 25, 35 ]
    } ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/ide0DblKUg",
      "expanded_url" : "https:\/\/www.youtube.com\/channel\/UC2F8FM_lVc-s32-XTE1y0iw\/live",
      "display_url" : "youtube.com\/channel\/UC2F8F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1054055280651071488",
  "text" : "https:\/\/t.co\/ide0DblKUg\n\n#Vtuber\u6E96\u5099\u4E2D https:\/\/t.co\/tm7TFB3zdk",
  "id" : 1054055280651071488,
  "created_at" : "2018-10-21 17:02:16 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1052578606180786178\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/gaaL1dRRdt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dpt_YOZUcAMDiTg.jpg",
      "id_str" : "1052574992079024131",
      "id" : 1052574992079024131,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dpt_YOZUcAMDiTg.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 1280
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/gaaL1dRRdt"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1052578606180786178\/photo\/1",
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/gaaL1dRRdt",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DpuCaGcU8AA_M_2.jpg",
      "id_str" : "1052578322838777856",
      "id" : 1052578322838777856,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DpuCaGcU8AA_M_2.jpg",
      "sizes" : [ {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/gaaL1dRRdt"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1052578606180786178",
  "text" : "https:\/\/t.co\/gaaL1dRRdt",
  "id" : 1052578606180786178,
  "created_at" : "2018-10-17 15:14:30 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1051883556157321217\/video\/1",
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/WlaeK1iQNs",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1051883476033490944\/pu\/img\/ROasaAtY7Vc8puXP.jpg",
      "id_str" : "1051883476033490944",
      "id" : 1051883476033490944,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1051883476033490944\/pu\/img\/ROasaAtY7Vc8puXP.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/WlaeK1iQNs"
    } ],
    "hashtags" : [ {
      "text" : "VTuber\u6E96\u5099\u4E2D",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1051883556157321217",
  "text" : "#VTuber\u6E96\u5099\u4E2D https:\/\/t.co\/WlaeK1iQNs",
  "id" : 1051883556157321217,
  "created_at" : "2018-10-15 17:12:37 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1051163283078537216\/photo\/1",
      "indices" : [ 2, 25 ],
      "url" : "https:\/\/t.co\/ASGBziJlm0",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DpZ4m7AV4AAsdeV.jpg",
      "id_str" : "1051160173107077120",
      "id" : 1051160173107077120,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DpZ4m7AV4AAsdeV.jpg",
      "sizes" : [ {
        "h" : 511,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 861
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 861
      }, {
        "h" : 647,
        "resize" : "fit",
        "w" : 861
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/ASGBziJlm0"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1051163283078537216",
  "text" : "\uD83D\uDE28 https:\/\/t.co\/ASGBziJlm0",
  "id" : 1051163283078537216,
  "created_at" : "2018-10-13 17:30:31 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1051125171216498695\/video\/1",
      "indices" : [ 13, 36 ],
      "url" : "https:\/\/t.co\/qYpQU38bau",
      "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1051124451775934464\/pu\/img\/dxRQrjBP4pOu4Mit.jpg",
      "id_str" : "1051124451775934464",
      "id" : 1051124451775934464,
      "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1051124451775934464\/pu\/img\/dxRQrjBP4pOu4Mit.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      }, {
        "h" : 720,
        "resize" : "fit",
        "w" : 720
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/qYpQU38bau"
    } ],
    "hashtags" : [ {
      "text" : "VTuber\u6E96\u5099\u4E2D",
      "indices" : [ 2, 12 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1051125171216498695",
  "text" : "\uD83D\uDE25\n#VTuber\u6E96\u5099\u4E2D https:\/\/t.co\/qYpQU38bau",
  "id" : 1051125171216498695,
  "created_at" : "2018-10-13 14:59:04 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1050792780623036416\/photo\/1",
      "indices" : [ 11, 34 ],
      "url" : "https:\/\/t.co\/6J8NmbsfQd",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DpUigJdV4AEs_Aj.jpg",
      "id_str" : "1050784023751024641",
      "id" : 1050784023751024641,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DpUigJdV4AEs_Aj.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 840
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 840
      }, {
        "h" : 670,
        "resize" : "fit",
        "w" : 840
      }, {
        "h" : 542,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/6J8NmbsfQd"
    } ],
    "hashtags" : [ {
      "text" : "VTuber\u6E96\u5099\u4E2D",
      "indices" : [ 0, 10 ]
    } ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1050792780623036416",
  "text" : "#VTuber\u6E96\u5099\u4E2D https:\/\/t.co\/6J8NmbsfQd",
  "id" : 1050792780623036416,
  "created_at" : "2018-10-12 16:58:16 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
} ]