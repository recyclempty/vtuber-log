Grailbird.data.tweets_2019_02 = 
[ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u308B\u3055\u3081",
      "screen_name" : "harusame_1190",
      "indices" : [ 0, 14 ],
      "id_str" : "964125920163282944",
      "id" : 964125920163282944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1097241396119928833",
  "geo" : { },
  "id_str" : "1097568147928842240",
  "in_reply_to_user_id" : 964125920163282944,
  "text" : "@harusame_1190 \u3042\u308A\u304C\u3068\u3046\n\u601D\u3044\u304C\u4F1D\u308F\u308B\u306F\u91CD\u8981\u306A\u3053\u3068\u306A\u306E\u306B\n\u4EBA\u3068\u558B\u308B\u3053\u3068\u306B\u3042\u307E\u308A\u81EA\u4FE1\u304C\u3042\u308A\u307E\u305B\u3093\n\u591A\u5206\u3001\u4E00\u751F\u306E\u8AB2\u984C\u3067\u3059",
  "id" : 1097568147928842240,
  "in_reply_to_status_id" : 1097241396119928833,
  "created_at" : "2019-02-18 18:46:52 +0000",
  "in_reply_to_screen_name" : "harusame_1190",
  "in_reply_to_user_id_str" : "964125920163282944",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EB\u30D5\u30A9",
      "screen_name" : "TKTKta",
      "indices" : [ 0, 7 ],
      "id_str" : "2241613614",
      "id" : 2241613614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1097270117140852737",
  "geo" : { },
  "id_str" : "1097567665516773376",
  "in_reply_to_user_id" : 2241613614,
  "text" : "@TKTKta \u3042\u308A\u304C\u3068\u3046\n\u30AC\u30EB\u30D5\u30A9\u3055\u3093\u3082\u305F\u304F\u3055\u3093\u306E\u4EBA\u306B\u5FDC\u63F4\u3057\u3066\n\u4F8B\u3048\u5FDC\u63F4\u3059\u308B\u3060\u3051\u3067\u3082\u3001\u7D9A\u3051\u308B\u3053\u3068\u306E\u52D5\u529B\u306B\u306A\u308B\n\u3068\u3063\u3066\u3082\u3048\u3089\u3044\u4E8B\u3068\u601D\u3063\u3066\u3044\u307E\u3059",
  "id" : 1097567665516773376,
  "in_reply_to_status_id" : 1097270117140852737,
  "created_at" : "2019-02-18 18:44:57 +0000",
  "in_reply_to_screen_name" : "TKTKta",
  "in_reply_to_user_id_str" : "2241613614",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "TL",
      "screen_name" : "TL001210",
      "indices" : [ 0, 9 ],
      "id_str" : "1059482894761103360",
      "id" : 1059482894761103360
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1097231128153522182",
  "geo" : { },
  "id_str" : "1097538490823143431",
  "in_reply_to_user_id" : 1059482894761103360,
  "text" : "@TL001210 \u3042\u308A\u304C\u3068\u3046\u3001GameMaker\u3082\u9811\u5F35\u3063\u3066",
  "id" : 1097538490823143431,
  "in_reply_to_status_id" : 1097231128153522182,
  "created_at" : "2019-02-18 16:49:02 +0000",
  "in_reply_to_screen_name" : "TL001210",
  "in_reply_to_user_id_str" : "1059482894761103360",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u308B\u3055\u3081",
      "screen_name" : "harusame_1190",
      "indices" : [ 0, 14 ],
      "id_str" : "964125920163282944",
      "id" : 964125920163282944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1089782926680543232",
  "geo" : { },
  "id_str" : "1097222595340947456",
  "in_reply_to_user_id" : 964125920163282944,
  "text" : "@harusame_1190 \u3042\u308A\u304C\u3068\u3046",
  "id" : 1097222595340947456,
  "in_reply_to_status_id" : 1089782926680543232,
  "created_at" : "2019-02-17 19:53:46 +0000",
  "in_reply_to_screen_name" : "harusame_1190",
  "in_reply_to_user_id_str" : "964125920163282944",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1097221833097588736\/photo\/1",
      "indices" : [ 142, 165 ],
      "url" : "https:\/\/t.co\/QFHtAzn4tP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DzobakVUwAANibm.jpg",
      "id_str" : "1097219602461802496",
      "id" : 1097219602461802496,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DzobakVUwAANibm.jpg",
      "sizes" : [ {
        "h" : 1077,
        "resize" : "fit",
        "w" : 1077
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 680,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1077,
        "resize" : "fit",
        "w" : 1077
      }, {
        "h" : 1077,
        "resize" : "fit",
        "w" : 1077
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/QFHtAzn4tP"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1097221833097588736\/photo\/1",
      "indices" : [ 142, 165 ],
      "url" : "https:\/\/t.co\/QFHtAzn4tP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dzobcb5U0AAA5n8.jpg",
      "id_str" : "1097219634556620800",
      "id" : 1097219634556620800,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dzobcb5U0AAA5n8.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 3413,
        "resize" : "fit",
        "w" : 4096
      }, {
        "h" : 1000,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 567,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1707,
        "resize" : "fit",
        "w" : 2048
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/QFHtAzn4tP"
    }, {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1097221833097588736\/photo\/1",
      "indices" : [ 142, 165 ],
      "url" : "https:\/\/t.co\/QFHtAzn4tP",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dzoblk8U0AA5Cps.png",
      "id_str" : "1097219791603945472",
      "id" : 1097219791603945472,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dzoblk8U0AA5Cps.png",
      "sizes" : [ {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 400,
        "resize" : "fit",
        "w" : 400
      }, {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/QFHtAzn4tP"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1097221833097588736",
  "text" : "\u3061\u3087\u3063\u3068\u898B\u76EE\u304C\u5909\u308F\u3063\u305F\n\n\u4F55\u65E5\u5F8C\u3067\u3001\u30C4\u30A4\u30FC\u30C8\u5168\u90E8\u3092\u7206\u767A\u3059\u308B\n\u306A\u3093\u304B\u3001vtuber\u3084\u914D\u4FE1\u8005\u306B\u3089\u3057\u304F\u306A\u3044\u306E\u3067\n\u305D\u3057\u3066\u3001\u3084\u308A\u76F4\u3059\u6C17\u6301\u3061\u3082\u3042\u308B\u3060\u304B\u3089\n\n\u3053\u308C\u304B\u3089\u7D9A\u3051\u3066V\u8005\u9054\u306B\u307F\u308B\u3068\n\u591A\u5206\u3001\u3042\u307E\u308A\u305D\u308C\u4EE5\u5916\u306E\u7269\u3092\u306A\u3055\u305D\u3046\n\n\u30C4\u30A4\u30FC\u30C8\u30C7\u30FC\u30BF\u304C\u3061\u3083\u3093\u3068\u4FDD\u5B58\u3055\u308C\u307E\u3059\u3001\u307E\u3041...\u672A\u6765\u3067\u9ED2\u6B74\u53F2\u306B\u306A\u308B\u3068\u304B https:\/\/t.co\/QFHtAzn4tP",
  "id" : 1097221833097588736,
  "created_at" : "2019-02-17 19:50:45 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1097219235254693888",
  "geo" : { },
  "id_str" : "1097219236638842880",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u30D5\u30A9\u30ED\u30FC\u3057\u305F\u306E\u7406\u7531\u3066\u5B9F\u306F\u3042\u308B\n\u8A71\u3057\u304B\u3051\u3066\u304F\u308C\u3066\u306E\u4EBA\u3092\u5FD8\u308C\u306A\u3044\u3088\u3046\u306B\u3001\u30D5\u30A9\u30ED\u30FC\u3057\u3066\u3044\u307E\u3059\n\u4EE5\u524D\u304B\u3089\u3001\u540D\u79F0\u3084\u540D\u524D\u304C\u7279\u306B\u5FD8\u308C\u3084\u3059\u3044\n\u306A\u3093\u304B\u3001\u56F0\u3089\u305B\u3066\u3057\u3060\u3001\u3054\u3081\u3093\u306A\u3055\u3044",
  "id" : 1097219236638842880,
  "in_reply_to_status_id" : 1097219235254693888,
  "created_at" : "2019-02-17 19:40:26 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1097219236638842880",
  "geo" : { },
  "id_str" : "1097219238073315329",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u5168\u90E8\u8A71\u3092\u7D42\u308F\u308A\u3060\n\u4ECA\u56DE\u306E\u8A71\u304C\u6587\u6CD5\u3084\u8A00\u8449\u3092\u8A02\u6B63\u3057\u3066\u306A\u3044\n\u3082\u3057\u5909\u306A\u8A00\u8449\u3092\u8A00\u3063\u305F\u3001\u8A31\u3057\u3066\u304F\u3060\u3055\u3044\n\n\u305D\u3046\u3060\u3001\u6BCE\u56DE\u5BDD\u308B\u524D\u306B\u30C4\u30A4\u30FC\u30C8\u3057\u3066\u539F\u56E0\u3082\u3042\u308B\n\u30C4\u30A4\u30FC\u30C8\u3059\u308B\u5F8C\u306B\u3001\u3061\u3087\u3063\u3068\u3000\u30B3\u30E1\u30F3\u30C8\u3092\u6050\u308C\u3066\u3044\u308B\u3057\n\u4ED6\u306E\u3053\u3068\u3092\u3067\u304D\u306A\u3044\u3001\u3059\u307F\u307E\u305B\u3093\u3067\u3057\u305F",
  "id" : 1097219238073315329,
  "in_reply_to_status_id" : 1097219236638842880,
  "created_at" : "2019-02-17 19:40:26 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1097219231018496000",
  "geo" : { },
  "id_str" : "1097219232494903296",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u5C11\u3057\u5225\u306E\u8A71\u306B\u3059\u308B\n\u6700\u521D\u306F\u78BA\u304B\u306B\u611F\u60C5\u306E\u307E\u307E\u306B\u884C\u52D5\u3059\u308B\n\u81EA\u5206\u306B\u3068\u3063\u3066\u7121\u7406\u306A\u4E8B\u3092\u3057\u3066\u3001\u3084\u3063\u3071\u308A\u30C0\u30E1\u3060\n\n\u5143\u3005\u56FD\u8A9E\u306E\u624D\u80FD\u304C\u3042\u308A\u307E\u305B\u3093\nSNS\u3092\u4F7F\u3063\u3066\u306A\u3093\u3066\u307E\u308B\u3067\u30B3\u30DF\u30E5\u969C\u307F\u305F\u3044\n\u65E5\u672C\u8A9E\u304C\u6BCD\u8A9E\u3067\u306F\u306A\u3044\u306E\u539F\u56E0\u3082\u3042\u308A\u3066\n\u8A00\u3044\u9593\u9055\u3044\u304C\u6016\u3044\u306A\u3093\u3068...",
  "id" : 1097219232494903296,
  "in_reply_to_status_id" : 1097219231018496000,
  "created_at" : "2019-02-17 19:40:25 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1097219232494903296",
  "geo" : { },
  "id_str" : "1097219233891504128",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u3084\u308A\u305F\u3044\u3053\u3068\u3092\u5B9F\u73FE\u3059\u308B\u306E\u80FD\u529B\u304C\u8DB3\u308A\u306A\u3044\n\u7D75\u3001\u52D5\u753B\u3001\u30D7\u30ED\u30B0\u30E9\u30E0\u3001\u6B4C\u3001\u97F3\u697D\u7B49\u3005\n\u8077\u4EBA\u307E\u3067\u671B\u3093\u3067\u306F\u306A\u3044\u3001\u305B\u3081\u3066\u4E00\u4EBA\u3067\u3067\u304D\u308B\u307B\u3057\u3044\n\n\u4ECA\u7D9A\u304F\u7406\u7531\u306F\u3053\u306E\u5B50\u306E\u305F\u3081\n\u306A\u3093\u304B\u3001\u81EA\u5206\u304C\u3084\u3089\u306A\u3044\u306A\u3089\u3070\u5B58\u5728\u304C\u6D88\u3048\u53BB\u308C\u3068\u3044\u3046\u6C17\u6301\u3061\u304C\u3042\u308B\n\n\u304A\u305D\u3089\u304F\u3001\u305F\u3060\u306E\u3058\u3053\u307E\u3093\u305E\u304F\u304B\u3082",
  "id" : 1097219233891504128,
  "in_reply_to_status_id" : 1097219232494903296,
  "created_at" : "2019-02-17 19:40:25 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EB\u30D5\u30A9",
      "screen_name" : "TKTKta",
      "indices" : [ 22, 29 ],
      "id_str" : "2241613614",
      "id" : 2241613614
    }, {
      "name" : "\u306F\u308B\u3055\u3081",
      "screen_name" : "harusame_1190",
      "indices" : [ 37, 51 ],
      "id_str" : "964125920163282944",
      "id" : 964125920163282944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1097219233891504128",
  "geo" : { },
  "id_str" : "1097219235254693888",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u3082\u3046\u4E00\u3064\u3001\u8A71\u3057\u304B\u3051\u3066\u304F\u308C\u3066\n\n\u30AC\u30EB\u30D5\u30A9\u3055\u3093\u3000@TKTKta\n\u306F\u308B\u3055\u3081\u3055\u3093\u3000@harusame_1190\n\n\u672C\u5F53\u306B\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\n\u3082\u3063\u3069\u611F\u8B1D\u306E\u6C17\u6301\u3061\u3092\u66F8\u304D\u305F\u3044\n\u305D\u3093\u306A\u8A9E\u5F59\u4E0D\u8DB3\u306E\u3066\u3001\u8A31\u3057\u3066\u304F\u3060\u3055\u3044",
  "id" : 1097219235254693888,
  "in_reply_to_status_id" : 1097219233891504128,
  "created_at" : "2019-02-17 19:40:25 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1097219229646868481",
  "text" : "\u307E\u305A\u3001\u9045\u304F\u306A\u3063\u3066\u3059\u307F\u307E\u305B\u3093\u3067\u3057\u305F\n\u5B9F\u306F\u3053\u306E\u30C6\u30AD\u30B9\u30C8\u304C\u7D50\u69CB\u524D\u306B\u3082\u3046\u66F8\u3044\u3066\u3044\u308B\n\u6BCE\u56DE\u9001\u308B\u524D\u306B\u8FF7\u3063\u3066\u3044\u308B\u3001\u3067\u3082\u3061\u3083\u3093\u3068\u8A00\u3046\u3053\u3068\u3057\u306A\u3044\u3068\u3060\u3081\u3060\n\n\u8272\u3005\u8003\u3048\u3066\u3044\u307E\u3057\u305F\u3002\u305D\u306E\u307E\u307E\u306B\u8AE6\u3081\u3066\u6B32\u3057\u304F\u306A\u3044\n\u3053\u306E\u5F8C\u3001\u7A7A\u304D\u6642\u9593\u304C\u5C11\u306A\u3044\u306E\u3067\u6D3B\u52D5\u3092\u5909\u66F4\u3057\u307E\u3059",
  "id" : 1097219229646868481,
  "created_at" : "2019-02-17 19:40:24 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 39, 62 ],
      "url" : "https:\/\/t.co\/DV0TLvv22p",
      "expanded_url" : "http:\/\/2.YouTube",
      "display_url" : "2.YouTube"
    } ]
  },
  "in_reply_to_status_id_str" : "1097219229646868481",
  "geo" : { },
  "id_str" : "1097219231018496000",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u5909\u66F4\u5185\u5BB9\u306F\u4EE5\u4E0B\n1.Twitter\u304C\u4E0D\u5B9A\u671F\u66F4\u65B0\u306B\u306A\u308B\u3001\u305D\u3057\u3066\u3042\u307E\u308A\u8A71\u3092\u3057\u306A\u3044\nhttps:\/\/t.co\/DV0TLvv22p\u30C1\u30E3\u30F3\u30CD\u30EB\u304C\u3057\u3070\u3089\u304F\u4F7F\u308F\u306A\u3044(\u89E3\u9664\u3057\u3066\u3082\u3044\u3044)\n\n\u3053\u308C\u304B\u3089\u76EE\u6A19\u306F\u4EE5\u4E0B\n1.\u30A4\u30E1\u30FC\u30B8\u3092\u4F5C\u6210\u3059\u308B\n2.\u81EA\u5206\u3092\u5F37\u304F\u306A\u308B\uFF08\u8272\u3005\uFF09",
  "id" : 1097219231018496000,
  "in_reply_to_status_id" : 1097219229646868481,
  "created_at" : "2019-02-17 19:40:24 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
} ]