Grailbird.data.tweets_2019_01 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1085950210465906688",
  "text" : "...\u3044\u308D\u3093\u306A\u4E8B\u3092\u767A\u751F\u3057\u305F\u3001\u7D9A\u3051\u308B\u3068\u304B\u308F\u304B\u3089\u306A\u3044\n\u3084\u308A\u305F\u3044\u6C17\u6301\u3061\u304C\u672C\u5F53\u3060\u3001\u3044\u307E\u3084\u3063\u3066\u3044\u308B\u3053\u3069\u306F\u4F55\u3082\u610F\u5473\u304C\u306A\u3044\u304B\u3082\n\u3067\u3082\u904E\u53BB\u3088\u3046\u306B\u4F55\u3082\u76EE\u6A19\u304C\u306A\u3044\u306E\u66AE\u3089\u3057\u306F\u7D76\u5BFE\u3044\u3084\u3067\u3059\n\n\u3057\u3070\u3089\u304F\u30C4\u30A4\u30FC\u30C8\u3057\u306A\u3044\u3001\u3069\u3046\u3059\u308B\u304B\u3092\u8003\u3048\u308B",
  "id" : 1085950210465906688,
  "created_at" : "2019-01-17 17:21:20 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1085625488410796032",
  "text" : "\u306F\u3084\u3044\uFF01\u3044\u3084\u3001\u3046\u3063...\n\u7406\u7531\u306F\u7406\u89E3\u3067\u304D\u308B\u3001\u4F01\u696D\u306B\u3068\u3063\u3066\u30A2\u30EC\u304C\u4ED5\u65B9\u306A\u3044\n\u3055\u3059\u304C\u4ECA\u306B\u306F\u5352\u696D\u5F0F\u306E\u3053\u3068\u3092\u601D\u3044\u51FA\u3057\u3066\u8349\u3057\u304B\u751F\u3048\u306A\u3044\n\u3067\u3082\u3001\u3053\u308C\u306F\u3088\u3044\u4E8B\u3067\u3059\u3001\u304D\u3063\u3068\u3046\u308C\u3057\u3044\u3060\u308D\uD83D\uDE42\n\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044\uD83D\uDCA4",
  "id" : 1085625488410796032,
  "created_at" : "2019-01-16 19:51:01 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B39\u6728\u54B2\uD83C\uDF8B",
      "screen_name" : "saku_sasaki",
      "indices" : [ 3, 15 ],
      "id_str" : "1012211447160455170",
      "id" : 1012211447160455170
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/saku_sasaki\/status\/1085492783098417152\/photo\/1",
      "indices" : [ 104, 127 ],
      "url" : "https:\/\/t.co\/jdsSbugKoq",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DxBxhqmU8AAC_yW.jpg",
      "id_str" : "1085492333380956160",
      "id" : 1085492333380956160,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DxBxhqmU8AAC_yW.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 1276
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 718,
        "resize" : "fit",
        "w" : 1276
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/jdsSbugKoq"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 80, 103 ],
      "url" : "https:\/\/t.co\/bj3u2xJi5b",
      "expanded_url" : "https:\/\/youtu.be\/ayvKurh74ZE",
      "display_url" : "youtu.be\/ayvKurh74ZE"
    } ]
  },
  "geo" : { },
  "id_str" : "1085617982179467264",
  "text" : "RT @saku_sasaki: \u304A\u4E45\u3057\u3076\u308A\u3067\u3059\u3002\u5FA9\u5E30\u3055\u305B\u3066\u3044\u305F\u3060\u304F\u4E8B\u306B\u306A\u308A\u307E\u3057\u305F\u3002\n\u3053\u308C\u304B\u3089\u307E\u305F\u3088\u308D\u3057\u304F\u304A\u9858\u3044\u81F4\u3057\u307E\u3059\u3002\n\n\u7686\u69D8\u306B\u5927\u5207\u306A\u304A\u77E5\u3089\u305B\u304C\u3042\u308A\u307E\u3059\u3002\nhttps:\/\/t.co\/bj3u2xJi5b https:\/\/t.co\/jdsSbugKoq",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/saku_sasaki\/status\/1085492783098417152\/photo\/1",
        "indices" : [ 87, 110 ],
        "url" : "https:\/\/t.co\/jdsSbugKoq",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DxBxhqmU8AAC_yW.jpg",
        "id_str" : "1085492333380956160",
        "id" : 1085492333380956160,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DxBxhqmU8AAC_yW.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 718,
          "resize" : "fit",
          "w" : 1276
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 718,
          "resize" : "fit",
          "w" : 1276
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/jdsSbugKoq"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 63, 86 ],
        "url" : "https:\/\/t.co\/bj3u2xJi5b",
        "expanded_url" : "https:\/\/youtu.be\/ayvKurh74ZE",
        "display_url" : "youtu.be\/ayvKurh74ZE"
      } ]
    },
    "geo" : { },
    "id_str" : "1085492783098417152",
    "text" : "\u304A\u4E45\u3057\u3076\u308A\u3067\u3059\u3002\u5FA9\u5E30\u3055\u305B\u3066\u3044\u305F\u3060\u304F\u4E8B\u306B\u306A\u308A\u307E\u3057\u305F\u3002\n\u3053\u308C\u304B\u3089\u307E\u305F\u3088\u308D\u3057\u304F\u304A\u9858\u3044\u81F4\u3057\u307E\u3059\u3002\n\n\u7686\u69D8\u306B\u5927\u5207\u306A\u304A\u77E5\u3089\u305B\u304C\u3042\u308A\u307E\u3059\u3002\nhttps:\/\/t.co\/bj3u2xJi5b https:\/\/t.co\/jdsSbugKoq",
    "id" : 1085492783098417152,
    "created_at" : "2019-01-16 11:03:41 +0000",
    "user" : {
      "name" : "\u7B39\u6728\u54B2\uD83C\uDF8B",
      "screen_name" : "saku_sasaki",
      "protected" : false,
      "id_str" : "1012211447160455170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1102661321672163328\/3UWnrxaI_normal.jpg",
      "id" : 1012211447160455170,
      "verified" : false
    }
  },
  "id" : 1085617982179467264,
  "created_at" : "2019-01-16 19:21:11 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1085253215057108992",
  "text" : "\u6700\u8FD1\u52C9\u5F37\u3057\u3066\u305D\u308D\u305D\u308D\u3080\u3064\u304B\u3057\u3044\u672C\u3092\u8AAD\u3093\u3067\u307F\u308B\n\u3061\u3087\u3063\u3068\u524D\u306B\u30A4\u30F3\u30BF\u30FC\u30CD\u30C3\u30C8\u306E\u9752\u7A7A\u6587\u5EAB\u3092\u63A2\u3057\u3066\u3044\u305F\n\u8AAD\u3093\u3067\u307F\u305F\u3042\u3068\u3001\u3046\u3063\u2026\u9577\u3044\uFF01\u6587\u5B57\u304C\u591A\u3044\uFF01\n\u4E0A\u624B\u306B\u306A\u308B\u305F\u3081\u306B\u3001\u898B\u308B\u3057\u304B\u306A\u3044\u3060\n\n\u305D\u3046\u305F\u3001\u3055\u304D\u5263\u6301\u3055\u3093\u306E\u914D\u4FE1\u2026\u3002\u3044\u3084\u3001\u306A\u3093\u3067\u3082\u306A\u3044\n\u3066\u3082\u666E\u6BB5\u306E\u307E\u307E\u558B\u3063\u3066\u306A\u3093\u304B\u884C\u3051\u308B\uD83E\uDD14\n\n\u304A\u3084\u3059\u307F\u306A\u3055\u3044\uD83D\uDCA4",
  "id" : 1085253215057108992,
  "created_at" : "2019-01-15 19:11:44 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1084910065247707137",
  "text" : "\u3082\u3063\u3068\u3084\u308C\u308B\u3001\u3082\u3063\u3068\u81EA\u5206\u306E\u80FD\u529B\u304C\u8DB3\u308A\u306A\u3044\u306E\u3053\u3068\u3092\u8A8D\u8B58\u3057\u305F\n\u5C11\u3057\u81EA\u5206\u306E\u6A19\u6E96\u3092\u4E0B\u3052\u3066\u901F\u5EA6\u3092\u4E0A\u3052\u305F\u307B\u3046\u304C\u3044\u3044\u304B\u3082\n\u305B\u3081\u3066\u4ECA\u306E\u5B9F\u529B\u3092\u3061\u3083\u3093\u3068\u628A\u63E1\u3059\u308B...\n\n\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044\uD83D\uDCA4",
  "id" : 1084910065247707137,
  "created_at" : "2019-01-14 20:28:10 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u308B\u3055\u3081",
      "screen_name" : "harusame_1190",
      "indices" : [ 0, 14 ],
      "id_str" : "964125920163282944",
      "id" : 964125920163282944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1084539394919325696",
  "geo" : { },
  "id_str" : "1084908686655467521",
  "in_reply_to_user_id" : 964125920163282944,
  "text" : "@harusame_1190 \uD83D\uDE42",
  "id" : 1084908686655467521,
  "in_reply_to_status_id" : 1084539394919325696,
  "created_at" : "2019-01-14 20:22:42 +0000",
  "in_reply_to_screen_name" : "harusame_1190",
  "in_reply_to_user_id_str" : "964125920163282944",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1084538976659169280",
  "text" : "\u6709\u6816\u5DDD \u30C9\u30C3\u30C8\u3055\u3093\u306E\u521D\u914D\u4FE1\u3092\u898B\u307E\u3057\u305F\n\u3059\u3054\u3044\u3067\u3059\u3001\u4EE5\u524D\u30B3\u30E1\u30F3\u30C8\u6B04\u3068\u9023\u52D5\u3057\u3066\u898B\u305F\u3053\u3068\u304C\u3042\u308B\n\u305F\u3060\u6D41\u3059\u3068\u3001\u3061\u3087\u3063\u3068\u3082\u3063\u305F\u3044\u306A\u3044\u3068\u601D\u3046\n\u3082\u3057\u4F55\u304B\u306B\u30B3\u30F3\u30C8\u30ED\u30FC\u30EB\u304C\u3067\u304D\u308B\u306A\u3089\n\u4E2D\u3067\u4E00\u54E1\u306A\u3089\u3001\u304D\u3063\u3068\u9762\u767D\u3044\n\n\u6094\u3057\u3044\u3051\u3069\u3001\u3067\u3082\u898B\u305F\u5B09\u3057\u3044\n\n\u3046\u307E\u304F\u8A71\u305B\u306A\u3044\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044\uD83D\uDCA4",
  "id" : 1084538976659169280,
  "created_at" : "2019-01-13 19:53:36 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1084165932434354176",
  "geo" : { },
  "id_str" : "1084165933856305152",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u3067\u3082\u3001\u5B9F\u969B\u79C1\u306F\u30B9\u30D0\u30EB\u3055\u3093\u306E\u58F0\u304C\u53EF\u611B\u3044\u3068\u601D\u3046\n\u305F\u3060\u4F7F\u3044\u65B9\u306F\u8352\u3005\u3057\u3044\u3067\u3059\uD83D\uDCAA\n\n\u3042\u3068\u3001\u521D\u3081\u3066\u77E5\u3063\u305F\n\u57CE\u661F\u8B72\u53CB&amp;VIC\u306F\u30DB\u30F3\u30C8\u306B\u4E8C\u4EBA\u3060\u3063\u305F\n\u305A\u3063\u3068\u305F\u3060\u306E\u30B9\u30BF\u30F3\u30C9\u3060\u3068\u601D\u3046\n\u305D\u3057\u3066\u3001\u57CE\u661F\u8B72\u53CB\u3055\u3093\u304C\u304B\u308F\u3044\u3044\u3067\u3059\uD83D\uDE42\n\n\u304A\u3084\u3059\u307F\uD83D\uDCA4",
  "id" : 1084165933856305152,
  "in_reply_to_status_id" : 1084165932434354176,
  "created_at" : "2019-01-12 19:11:16 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1084165932434354176",
  "text" : "\u6700\u8FD1\u30DE\u30A4\u30AF\u30E9\u914D\u4FE1\u591A\u3067\u3059\u3001BANS\u307E\u3067\u3082\u30B5\u30FC\u30D0\u30FC\u3092\u4F5C\u308A\u307E\u3057\u305F\n\u3084\u306F\u308A\u3001\u591A\u304F\u306E\u4EBA\u304C\u4E00\u7DD2\u306B\u904A\u3076\u306E\u65B9\u304C\u697D\u3057\u3044\u3067\u3059\n\n\u30DB\u30ED\u30E9\u30A4\u30D6\u306E\u30B9\u30D0\u30EB\u3055\u3093\u306F\u6700\u8FD1\u3082\u9762\u767D\u304B\u3063\u305F\n\u5143\u3005\u9762\u767D\u3044\u4EBA\u3060\u3001\u6700\u8FD1\u914D\u4FE1\u3055\u3059\u304C\u7206\u7B11\u3057\u3061\u3083\u3063\u305F\n3D\u3068\u304CASMR\u3068\u304C\u732B\u30AB\u30D5\u30A7\u3068\u304C\n\u4ECA\u65E5\u306E\u914D\u4FE1\u3082\u7B11\u3046\u3057\u304B\u306D\u3048\uD83D\uDE42",
  "id" : 1084165932434354176,
  "created_at" : "2019-01-12 19:11:15 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1083777669697695749",
  "text" : "\u6700\u8FD1\u306B\u3058\u3055\u3093\u3058\u30DE\u30A4\u30AF\u30E9\u914D\u4FE1\u306F\u9762\u767D\u304B\u3063\u305F\u3067\u3059\n\u7279\u306B\u6700\u8FD1\u306E\u30EA\u30AA\u30F3\u3055\u3093\u3001\u9762\u767D\u304F\u3066\u3001\u53EF\u611B\u304F\u3066\u3001\u662F\u975E\u898B\u3066\u307F\u3066\u304F\u3060\u3055\u3044\n\n\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u307E\u3060\u5C11\u3057\u75B2\u308C\u304C\u3042\u308B\u3088\u3046\u3067\u3059\n\u304A\u3084\u3059\u307F\uD83D\uDCA4",
  "id" : 1083777669697695749,
  "created_at" : "2019-01-11 17:28:26 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1083432424900448256",
  "text" : "\u5C11\u3057\u6628\u65E5\u30D0\u30FC\u30C1\u30E3\u30EB\u3055\u3093\u306E\u3053\u3068\u3092\u8A71\u3057\u307E\u3059\n\n\u30D5\u30A1\u30F3\u3068\u3057\u3066\u306E\u79C1\u306F\u898B\u3066\u3001\u3068\u3066\u3082\u697D\u3057\u3044\n\u6DF7\u4E71\u3067\u3059\u3051\u3069\u3001\u5206\u304B\u3063\u3066\u308B\u306E\u3067\u7B11\u3044\u307E\u3057\u305F\uD83D\uDE42\n\n\u540C\u6642\u306B\u3001\u308F\u304B\u3089\u306A\u3044\u4EBA\u306F\u898B\u3066\u697D\u3057\u3044\u306A\u306E\uFF1F\n...\u305D\u308C\u3082\u79C1\u304C\u5FC3\u914D\u3079\u304D\u3067\u306F\u306A\u3044\u306E\u3053\u3069\u3067\u3059\n\n\u3068\u308A\u3042\u3048\u305A\u6628\u65E5\u697D\u3057\u3066\u9045\u304F\u5BDD\u904E\u304E\u3060\u3001\u307E\u3060\u75B2\u308C\u3066\u3044\u308B\n\u304A\u3084\u3059\u307F\uD83D\uDCA4",
  "id" : 1083432424900448256,
  "created_at" : "2019-01-10 18:36:33 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1083101918577143808",
  "text" : "\u3084\u306F\u308A\u6DF7\u6C8C...\n\u4ED6\u306E\u4EBA\u306E\u30B3\u30E1\u30F3\u30C8\u3092\u898B\u904E\u304E\u3066\u3001\u3082\u3046\u3053\u3093\u306A\u6642\u9593...\n\u304A\u3084\u3059\u307F\uD83D\uDCA4",
  "id" : 1083101918577143808,
  "created_at" : "2019-01-09 20:43:15 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1082697116554674176",
  "geo" : { },
  "id_str" : "1082697117896912896",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u6700\u8FD1\u6BCE\u65E5\u3084\u308A\u3059\u304E\u3066\u66F8\u304F\u6642\u9593\u304C\u8DB3\u308A\u306A\u3044\n\u3044\u3063\u305D\u5148\u306B\u66F8\u3051\u3057\u3066\u3001\u3053\u308C\u3066\u5B89\u5FC3\u3057\u3066\u4ED6\u306E\u3053\u3068\u3092\u3084\u308B\n\u5C11\u3005\u75B2\u308C\u305F\u3001\u3082\u3046\u5C11\u3057\u3057\u305F\u3089\u5BDD\u307E\u3059\n\u304A\u3084\u3059\u307F\uD83D\uDCA4",
  "id" : 1082697117896912896,
  "in_reply_to_status_id" : 1082697116554674176,
  "created_at" : "2019-01-08 17:54:43 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1082697116554674176",
  "text" : "\u306B\u3058\u3055\u3093\u3058\u65B0\u3057\u3044\u30E9\u30A4\u30D0\u30FC\u304C\n...\u3042\u308C\u3001\u30E6\u30FC\u30C9\u30EA\u30C3\u30AF\u306F\uD83E\uDD14\n\nHTC\u306E\u8996\u7DDA\u8FFD\u8DE1\u306EVR\u30B4\u30FC\u30B0\u30EB\u304C\n\u3044\u3044\u306D\u3001\u3057\u304B\u3057\u4FA1\u683C\u306B...\n\n\u3064\u3044\u306B\u660E\u65E5\u3001\u30D0\u30FC\u30C1\u30E3\u30EB\u3055\u3093...\n\u4ECA\u65E5\u306E\u6700\u65B0\u6620\u50CF\u3092\u898B\u307E\u3057\u305F\n\u60F3\u50CF\u4EE5\u4E0A\u306B\u6DF7\u4E71\u3001\u3067\u3082\u30AB\u30C3\u30C8\u3057\u3059\u304E\u308B\u306E\u305B\u3044\u3067\u306E\u53EF\u80FD\u6027\u3082\u3042\u308A\u307E\u3059",
  "id" : 1082697116554674176,
  "created_at" : "2019-01-08 17:54:42 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306B\u3058\u3055\u3093\u3058\u516C\u5F0F\uD83C\uDF08\uD83D\uDD52 3\/6(\u6C34)21:00\u301C\u300C\u306B\u3058\u3055\u3093\u3058\u306E\u304F\u3058\u3058\u3085\u3046\u3058\u300D",
      "screen_name" : "nijisanji_app",
      "indices" : [ 3, 17 ],
      "id_str" : "950967576980422657",
      "id" : 950967576980422657
    } ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/nijisanji_app\/status\/1082472367694086144\/photo\/1",
      "indices" : [ 98, 121 ],
      "url" : "https:\/\/t.co\/jWYNwcIUzW",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/DwW20qVV4AAZiM6.jpg",
      "id_str" : "1082472301285728256",
      "id" : 1082472301285728256,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DwW20qVV4AAZiM6.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      }, {
        "h" : 675,
        "resize" : "fit",
        "w" : 1200
      }, {
        "h" : 383,
        "resize" : "fit",
        "w" : 680
      }, {
        "h" : 1080,
        "resize" : "fit",
        "w" : 1920
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/jWYNwcIUzW"
    } ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 74, 97 ],
      "url" : "https:\/\/t.co\/E9HYgs7CEh",
      "expanded_url" : "https:\/\/prtimes.jp\/main\/html\/rd\/p\/000000044.000030865.html",
      "display_url" : "prtimes.jp\/main\/html\/rd\/p\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1082665162752970753",
  "text" : "RT @nijisanji_app: \u3010\u306B\u3058\u3055\u3093\u3058\u304B\u30892\u540D\u304C\u65B0\u305F\u306B\u30C7\u30D3\u30E5\u30FC\uFF01\uFF01\u3011\n\n\u65B0\u3057\u304F2\u540D\u306E\u30E9\u30A4\u30D0\u30FC\u306E\u4EF2\u9593\u306B\u8FCE\u3048\u3001\u672C\u65E5\u3088\u308A\u59CB\u52D5\uFF01\n\u8A73\u7D30\u306F\u3053\u3061\u3089\u25B7https:\/\/t.co\/E9HYgs7CEh https:\/\/t.co\/jWYNwcIUzW",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/nijisanji_app\/status\/1082472367694086144\/photo\/1",
        "indices" : [ 79, 102 ],
        "url" : "https:\/\/t.co\/jWYNwcIUzW",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DwW20qVV4AAZiM6.jpg",
        "id_str" : "1082472301285728256",
        "id" : 1082472301285728256,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DwW20qVV4AAZiM6.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/jWYNwcIUzW"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 55, 78 ],
        "url" : "https:\/\/t.co\/E9HYgs7CEh",
        "expanded_url" : "https:\/\/prtimes.jp\/main\/html\/rd\/p\/000000044.000030865.html",
        "display_url" : "prtimes.jp\/main\/html\/rd\/p\u2026"
      } ]
    },
    "geo" : { },
    "id_str" : "1082472367694086144",
    "text" : "\u3010\u306B\u3058\u3055\u3093\u3058\u304B\u30892\u540D\u304C\u65B0\u305F\u306B\u30C7\u30D3\u30E5\u30FC\uFF01\uFF01\u3011\n\n\u65B0\u3057\u304F2\u540D\u306E\u30E9\u30A4\u30D0\u30FC\u306E\u4EF2\u9593\u306B\u8FCE\u3048\u3001\u672C\u65E5\u3088\u308A\u59CB\u52D5\uFF01\n\u8A73\u7D30\u306F\u3053\u3061\u3089\u25B7https:\/\/t.co\/E9HYgs7CEh https:\/\/t.co\/jWYNwcIUzW",
    "id" : 1082472367694086144,
    "created_at" : "2019-01-08 03:01:38 +0000",
    "user" : {
      "name" : "\u306B\u3058\u3055\u3093\u3058\u516C\u5F0F\uD83C\uDF08\uD83D\uDD52 3\/6(\u6C34)21:00\u301C\u300C\u306B\u3058\u3055\u3093\u3058\u306E\u304F\u3058\u3058\u3085\u3046\u3058\u300D",
      "screen_name" : "nijisanji_app",
      "protected" : false,
      "id_str" : "950967576980422657",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1085191620138479618\/wwB-jlfk_normal.jpg",
      "id" : 950967576980422657,
      "verified" : false
    }
  },
  "id" : 1082665162752970753,
  "created_at" : "2019-01-08 15:47:44 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u306F\u308B\u3055\u3081",
      "screen_name" : "harusame_1190",
      "indices" : [ 0, 14 ],
      "id_str" : "964125920163282944",
      "id" : 964125920163282944
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1082364968618536965",
  "geo" : { },
  "id_str" : "1082661737197961216",
  "in_reply_to_user_id" : 964125920163282944,
  "text" : "@harusame_1190 \u304A\u4F53\u306B\u6C17\u3092\u3064\u3051\u3066",
  "id" : 1082661737197961216,
  "in_reply_to_status_id" : 1082364968618536965,
  "created_at" : "2019-01-08 15:34:07 +0000",
  "in_reply_to_screen_name" : "harusame_1190",
  "in_reply_to_user_id_str" : "964125920163282944",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1082359788741091328",
  "text" : "\u4F55\u304C\u3092\u66F8\u304D\u305F\u3044\u3051\u3069\u3001\u3068\u3066\u3082\u5BDD\u305F\u3044...\n\u304A\u3084\u3059\u307F\uD83D\uDCA4",
  "id" : 1082359788741091328,
  "created_at" : "2019-01-07 19:34:17 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1082006190521896960",
  "text" : "\u6700\u8FD1\u3088\u304F\u304B\u306A\u3048\u3055\u3093\u306E\u30DE\u30A4\u30AF\u30E9\u914D\u4FE1\u3092\u898B\u3066\u3044\u307E\u3059\n\u591C\u914D\u4FE1\u3082\u4E00\u3064\u306E\u539F\u56E0(\u6700\u8FD1\u307B\u3068\u3093\u3069\u9045\u304F\u7720\u308B...\n\u30E1\u30F3\u30D0\u30FC\u3068\u7570\u306A\u308B\u30B2\u30FC\u30E0\u307F\u305F\u3044\u306E\u3053\u306E\u70B9\u306F\u9762\u767D\u3044\n\n\u3042\u3068\u3001AR\u304C\u51FA\u3066\u304F\u308B...\n\u305D\u308D\u305D\u308D\u5BDD\u308B\u308F\u3001\u304A\u3084\u3059\u307F\uD83D\uDCA4",
  "id" : 1082006190521896960,
  "created_at" : "2019-01-06 20:09:13 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u6A0B\u53E3\u6953",
      "indices" : [ 72, 76 ]
    } ],
    "urls" : [ {
      "indices" : [ 48, 71 ],
      "url" : "https:\/\/t.co\/GZ8DczZVPi",
      "expanded_url" : "http:\/\/live.nicovideo.jp\/watch\/lv317613259?ref=sharetw",
      "display_url" : "live.nicovideo.jp\/watch\/lv317613\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1081818685281513472",
  "text" : "\u3010\u30CB\u30B3\u751F\u8996\u8074\u4E2D\u3011\u6A0B\u53E3\u69531stLive\u300CKANA-DERO\u300D\u76F4\u524D\u7279\u756A\u3000\uFF5EDeroon 5\u306B\u8FEB\u308B\uFF5E https:\/\/t.co\/GZ8DczZVPi #\u6A0B\u53E3\u6953",
  "id" : 1081818685281513472,
  "created_at" : "2019-01-06 07:44:08 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1081649403373338624",
  "text" : "\u308F\u3041\uFF01\uFF1F\u307E\u3060\u3053\u3093\u306A\u6642\u9593\u304C...\n\n\u660E\u65E5\u306F\u3061\u3083\u3093\u3068\u65E9\u304F\u5BDD\u308B...\u304A\u3084\u3059\u307F\uD83D\uDCA4",
  "id" : 1081649403373338624,
  "created_at" : "2019-01-05 20:31:28 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1081242141282582528",
  "text" : "VTuber\u3069\u3093\u3069\u3093\u5E83\u304C\u3063\u3066\u3044\u308B\n\u3046\u308C\u3057\u3051\u3069...\u3067\u3082...\n\n\u3046\u307E\u304F\u8A00\u3048\u306A\u3044\u3001\u79C1\u306F\u6614\u304B\u3089\n\u6280\u8853\u3001\u624D\u80FD \u3001\u30B9\u30AD\u30EB\u3068\u3044\u3046\u7269\n\u305D\u306E\u6301\u3064\u4EBA\u3092\u5C0A\u656C\u3057\u3066\u3044\u308B\n\u3067\u3082\u5D07\u62DD\u3059\u308B\u3053\u3068\u306F\u3057\u306A\u3044\n\u305D\u306E\u305B\u3044\u3067\u7279\u306B\u8AB0\u304B\u306B\u5922\u4E2D\u306B\u306A\u308C\u307E\u305B\u3093",
  "id" : 1081242141282582528,
  "created_at" : "2019-01-04 17:33:09 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1081242141282582528",
  "geo" : { },
  "id_str" : "1081242142670913536",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u3084\u306F\u308A\u3046\u307E\u304F\u4F1D\u3048\u308B\u3067\u304D\u306A\u3044\n\u3082\u3057\u4ECA\u307E\u3067\u597D\u306E\u7269\u306F\u5909\u308F\u308C\u305F\u3001\u305D\u306E\u6642\u3069\u3046\u3055\u308C\u308B\u307E\u3059\u304B\n\n\u307E\u305F\u660E\u65E5",
  "id" : 1081242142670913536,
  "in_reply_to_status_id" : 1081242141282582528,
  "created_at" : "2019-01-04 17:33:09 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080914284404604928",
  "text" : "Minecraft\u3084\u3063\u3071\u308A\u305F\u304F\u3055\u3093\u306E\u4EBA\u3068\u904A\u3076\u307B\u3046\u304C\u697D\u3057\u3044\n\n\u6700\u8FD1\u307E\u3060\u7761\u7720\u4E0D\u8DB3\uFF0C\u660E\u65E5\u65E9\u304F\u5BDD\u306A\u3051\u308C\u3070\u306A\u308A\u307E\u305B\u3093\n\u304A\u3084\u3059\u307F\uD83D\uDCA4",
  "id" : 1080914284404604928,
  "created_at" : "2019-01-03 19:50:22 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u671D\u30CE\u7460\u7483\u272A3\/2(\u571F)12:00\uFF5E 1st VR LIVE\u30C1\u30B1\u30C3\u30C8\u767A\u58F2\uFF01\uFF01",
      "screen_name" : "asanoruri",
      "indices" : [ 3, 13 ],
      "id_str" : "991562536632778752",
      "id" : 991562536632778752
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080820361942298625",
  "text" : "RT @asanoruri: \u2728\u65B0\u6625\uFF01\u30D0\u30FC\u30C1\u30E3\u30EB\u6B4C\u5408\u6226\u2728\n\uD83C\uDF8D\u5E73\u621031\u5E741\u67083\u65E5(\u6728) 19:00\uFF5E\uD83C\uDF8D\n\n\u671D\u30CE\u59C9\u59B9\u3077\u308D\u3058\u3047\u304F\u3068\u306E\u30C1\u30E3\u30F3\u30CD\u30EB\u306B\u3066\u751F\u653E\u9001\uFF01\uFF01\n\n\u671D\u30CE\u7460\u7483\u7387\u3044\u308B\u3010\u6E05\u695A\u7D44\u3011\u3068\n\u3075\u304F\u3084\u30DE\u30B9\u30BF\u30FC\u7387\u3044\u308B\u3010\u7D0D\u8C46\u7D44\u3011\u304C\n\n\u65B0\u5E74\u304B\u3089\u6B4C\u3067\u9B45\u305B\u307E\u3059\u8074\u304B\u305B\u307E\u3059\uFF01\u1420( \u141B )\u141F\u1420( \u1416 )\u141F\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/android\" rel=\"nofollow\"\u003ETwitter for Android\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/asanoruri\/status\/1078848617035649025\/photo\/1",
        "indices" : [ 142, 165 ],
        "url" : "https:\/\/t.co\/sh9lO2erZa",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DvjXFR6U0AAT_wk.jpg",
        "id_str" : "1078848596462587904",
        "id" : 1078848596462587904,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DvjXFR6U0AAT_wk.jpg",
        "sizes" : [ {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/sh9lO2erZa"
      } ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1078848617035649025",
    "text" : "\u2728\u65B0\u6625\uFF01\u30D0\u30FC\u30C1\u30E3\u30EB\u6B4C\u5408\u6226\u2728\n\uD83C\uDF8D\u5E73\u621031\u5E741\u67083\u65E5(\u6728) 19:00\uFF5E\uD83C\uDF8D\n\n\u671D\u30CE\u59C9\u59B9\u3077\u308D\u3058\u3047\u304F\u3068\u306E\u30C1\u30E3\u30F3\u30CD\u30EB\u306B\u3066\u751F\u653E\u9001\uFF01\uFF01\n\n\u671D\u30CE\u7460\u7483\u7387\u3044\u308B\u3010\u6E05\u695A\u7D44\u3011\u3068\n\u3075\u304F\u3084\u30DE\u30B9\u30BF\u30FC\u7387\u3044\u308B\u3010\u7D0D\u8C46\u7D44\u3011\u304C\n\n\u65B0\u5E74\u304B\u3089\u6B4C\u3067\u9B45\u305B\u307E\u3059\u8074\u304B\u305B\u307E\u3059\uFF01\u1420( \u141B )\u141F\u1420( \u1416 )\u141F\u2728\u2728\n\n\u23EC\u51FA\u6F14\u8005\u7D39\u4ECB\u306F\u30C4\u30EA\u30FC\u3067\uFF01\u23EC https:\/\/t.co\/sh9lO2erZa",
    "id" : 1078848617035649025,
    "created_at" : "2018-12-29 03:02:08 +0000",
    "user" : {
      "name" : "\u671D\u30CE\u7460\u7483\u272A3\/2(\u571F)12:00\uFF5E 1st VR LIVE\u30C1\u30B1\u30C3\u30C8\u767A\u58F2\uFF01\uFF01",
      "screen_name" : "asanoruri",
      "protected" : false,
      "id_str" : "991562536632778752",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1099270290578665472\/g70oalYT_normal.png",
      "id" : 991562536632778752,
      "verified" : false
    }
  },
  "id" : 1080820361942298625,
  "created_at" : "2019-01-03 13:37:09 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080552949280006145",
  "text" : "\u3046...\u307E\u305F\u6642\u9593\u304C\n\n\u4E00\u65E6\u4F11\u307F\u307E\u3059\u3001\u304A\u3084\u3059\u307F\uD83D\uDCA4",
  "id" : 1080552949280006145,
  "created_at" : "2019-01-02 19:54:33 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1080178528157499392",
  "text" : "\u3042\u3051\u304A\u3081\uFF01\uD83C\uDF8D\uFF08\u6C17\u5206\u304C\u4E57\u3063\u3066\u3084\u3063\u3066\u307F\u308B\n\n\u5C11\u3057\u6574\u7406\u3057\u3066\u30B3\u30F3\u30C6\u30F3\u30C4\u3092\u8003\u3048\u307E\u3057\u305F\n\u3044\u3044\u30A2\u30A4\u30C7\u30A2\u304C\u6D6E\u304B\u3093\u3060\n\u305D\u306E\u524D\u306B\u307E\u305A\u3001\u81EA\u5DF1\u7D39\u4ECB\u3088\u3046\u306A\u3082\u306E\u3092\u4F5C\u308A\u307E\u3059\n\u307E\u3060\u6642\u9593\u304B\u304B\u308A\u305D\u3046\u3067\u3059\n\n\u305D\u308D\u305D\u308D\u4F11\u307F\u307E\u3059\u3001\u6700\u5F8C\u306B\u3001\u826F\u3044\u304A\u5E74\u3092",
  "id" : 1080178528157499392,
  "created_at" : "2019-01-01 19:06:44 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
} ]