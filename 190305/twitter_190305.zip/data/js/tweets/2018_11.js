Grailbird.data.tweets_2018_11 = 
 [ {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1068176223883259904",
  "text" : "\u524D\u306B\u6570\u65E5\u3084\u3066\u3001\u307E\u3060\u3061\u3087\u3063\u3068\u7761\u7720\u4E0D\u8DB3\n\u305D\u3046\u3044\u3048\u3070\u3001\u30A2\u30E1\u30EA\u30AB\u306E\u30D6\u30E9\u30C3\u30AF\u30D5\u30E9\u30A4\u30C7\u30FC\u304C\u524D\u9031\u306E23\u65E5\u59CB\u307E\u3063\u305F\n\u300C\u30D6\u30E9\u30C3\u30AF\u30D5\u30E9\u30A4\u30C7\u30FC\u3068\u306F\u300111\u6708\u306E\u7B2C4\u6728\u66DC\u65E5\u306E\u7FCC\u65E5\u306B\u3042\u305F\u308B\u65E5\u306E\u3053\u3068\u3067\u3042\u308B\u300D\n\u521D\u3081\u3066\u805E\u3044\u305F\u3001\u77E5\u3089\u306A\u304B\u3063\u305F...\uD83D\uDE36\n\n\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u660E\u65E5\u3082\u9811\u5F35\u308B",
  "id" : 1068176223883259904,
  "created_at" : "2018-11-29 16:13:52 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1067845571099021312",
  "text" : "live2D\u3067\u7ACB\u4F53\u7684\u306B\u8868\u73FE\u3059\u308B\u306E\u305F\u3081\u306B\u3001\u307E\u305A\u30AD\u30E5\u30FC\u30D6\u3092\u4F5C\u308B\nX\u8EF8\u3084Y\u8EF8\u30671\u3064\u306E\u8EF8\u3060\u3051\u56DE\u8EE2\u3059\u308B\u306B\u306F\u554F\u984C\u306A\u3044\n\u540C\u6642\u306B\u56DE\u3059\u306A\u3089\u30E2\u30C7\u30EB\u3092\u58CA\u3055\u308C\u305F\uD83D\uDCA6\n\n\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u660E\u65E5\u3082\u9811\u5F35\u308B",
  "id" : 1067845571099021312,
  "created_at" : "2018-11-28 18:19:58 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 0, 23 ],
      "url" : "https:\/\/t.co\/6qtNe33sCS",
      "expanded_url" : "https:\/\/github.com\/recyclempty\/vtuber-log\/tree\/1124_branch",
      "display_url" : "github.com\/recyclempty\/vt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1067463797537796096",
  "text" : "https:\/\/t.co\/6qtNe33sCS",
  "id" : 1067463797537796096,
  "created_at" : "2018-11-27 17:02:56 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1067463797537796096",
  "geo" : { },
  "id_str" : "1067463799060365313",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u3053\u308C\u3067\u4E00\u4EF6\u843D\u7740\n\u4E00\u4F53\u4F55\u65E5\u306B\u4F7F\u3048\u307E\u3057\u305F\u304B\uD83D\uDE15\n\n\u3068\u308A\u3042\u3048\u305A\u3001\u4ECA\u65E5\u306F\u65E9\u304F\u5BDD\u308B\n\u660E\u65E5\u304C\u4E88\u5B9A\u306E\u4E8B\u306B\u9811\u5F35\u308D",
  "id" : 1067463799060365313,
  "in_reply_to_status_id" : 1067463797537796096,
  "created_at" : "2018-11-27 17:02:56 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1066001442261979136",
  "text" : "\u660E\u65E5\u65E9\u3044\u8D77\u304D\u3066\u3001\u3042\u307E\u308A\u9577\u3044\u8003\u3048\u3066\u306A\u3044\n\u81EA\u5206\u306E\u30C4\u30A4\u30FC\u30C8\u306F\u610F\u5916\u306E\u4EBA\u306B\u898B\u3089\u308C\u305F\u3001\u3073\u3063\u304F\u308A\u3057\u305F\uD83D\uDCA6\nSNS\u306F\u305D\u3046\u3044\u3046\u3053\u3068\u304B...\n\n\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u660E\u65E5\u591A\u5206\u30C4\u30A4\u30FC\u30C8\u3092\u3057\u306A\u3044",
  "id" : 1066001442261979136,
  "created_at" : "2018-11-23 16:12:03 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1065652032315387904",
  "text" : "\u306B\u3058\u3055\u3093\u3058\u30EC\u30B8\u30B9\u30BF\u30F3\u30B9...\u3084\u3063\u3071\u308A\u9762\u767D\u3044\u3044\n\n\u305D\u3044\u3048\u3070\u3001\u81EA\u5206\u306A\u3093\u304C\u3053\u3046\u3044\u3046\u3050\u3060\u3050\u3060\u6C17\u5206\u304C\u3059\u304D\n\u9762\u767D\u3044\u756A\u7D44\u3082\u826F\u3044\u3001\u3082\u3069\u6C17\u8EFD\u306B\u307B\u3057\u3044\u3001\u9762\u5012\u306A\u79C1\uD83D\uDE15\n\n\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u660E\u65E5\u3082\u9811\u5F35\u308B",
  "id" : 1065652032315387904,
  "created_at" : "2018-11-22 17:03:38 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1065326037939118081",
  "text" : "\u5BC2\u3057\u3044\u306A\u3089\u3070\u30DA\u30C3\u30C8\u3092\u98FC\u3046\n\u3067\u3082\u3001\u3044\u3064\u304B\u96E2\u308C\u308B\u65E5\u304C\u6765\u308B\n\u305D\u308C\u3067\u6700\u521D\u304B\u3089\u3057\u306A\u3044\u307B\u3046\u304C\u3044\u3044\uFF1F\n\uFF08\uFF77\uFF6F\uFF84\uFF7F\uFF73\uFF7C\uFF9E\uFF6C\uFF85\uFF72\uFF09\n\n\u3046\u307E\u304F\u66F8\u3044\u3066\u306A\u3044\u3001\u3068\u308A\u3042\u3048\u305A\u3001\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u5C11\u3057\u4F11\u3080...",
  "id" : 1065326037939118081,
  "created_at" : "2018-11-21 19:28:14 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1064918428723474432",
  "text" : "\u4F7F\u3044\u306E\u30B9\u30DE\u30DB\u306E\u30D0\u30C3\u30C6\u30EA\u30FC\u306E\u5BFF\u547D\u304C\u6765\u305F...\n\u307E\u305F\u65B0\u3057\u3044\u30B9\u30DE\u30DB\u3092\u8CFC\u5165\u3057\u306A\u304D\u3083...\n\u306A\u3093\u3067\u30B9\u30DE\u30DB\u306E\u30D0\u30C3\u30C6\u30EA\u30FC\u304C\u4E7E\u96FB\u6C60\u307F\u305F\u3044\u306B\u3084\u3059\u3044\u66FF\u63DB\u54C1\u3092\u3067\u304D\u306A\u3044\u4F55\u306E\uD83E\uDD14\n\n\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u660E\u65E5\u3082\u9811\u5F35\u308B",
  "id" : 1064918428723474432,
  "created_at" : "2018-11-20 16:28:33 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1064581662187511808",
  "geo" : { },
  "id_str" : "1064581663273807872",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u3067\u3082\u3001\u3084\u3063\u3071\u308A\u81EA\u5206\u304C\u7518\u3044\u904E\u304E\u3060\n\u4ECA\u9031\u306B\u3084\u308B\u3053\u3068\u304C\u7D42\u308F\u308A\u3042\u3068\u3001\u3082\u4E00\u5EA6\u30C1\u30E3\u30EC\u30F3\u30B8\u3057\u3088\u3046\n\n\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u660E\u65E5\u3082\u9811\u5F35\u308B",
  "id" : 1064581663273807872,
  "in_reply_to_status_id" : 1064581662187511808,
  "created_at" : "2018-11-19 18:10:22 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1064581662187511808",
  "text" : "\u524Dlive2d\u3092\u7814\u7A76\u3059\u308B\u6642\u306B\u3001\u81EA\u7531\u306B\u8155\u56DE\u3059\u306E\u65B9\u6CD5\u304C\u63A2\u305B\u306A\u3044\n\u516C\u5F0F\u306E\u30B5\u30F3\u30D7\u30EB\u304C\u305B\u3044\u305C\u3044\u4E00\u8EF8\u306E\u56DE\u3059\u305F\u3051\n\u60A9\u3093\u3067\u3042\u3068\u306B\u30013D\u3092\u76F4\u63A5\u4F5C\u308B\u307B\u3046\u304C\u3044\u3044\u304B\u3082\u3001\u3068\u3044\u3046\u89E3\u6C7A\u3057\u307E\u3057\u305F",
  "id" : 1064581662187511808,
  "created_at" : "2018-11-19 18:10:21 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "vivi\uFF0F\uD83D\uDD25\u7114\u6A5F\u30D1\u30A4\u30ED(\u30D0\u7F8E\u8089VTuber)\uD83C\uDF46\uD83D\uDC1F\u264E\uD83C\uDF08",
      "screen_name" : "memento_vivi",
      "indices" : [ 3, 16 ],
      "id_str" : "103879620",
      "id" : 103879620
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 60, 68 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 36, 59 ],
      "url" : "https:\/\/t.co\/Oa6uHGl95q",
      "expanded_url" : "https:\/\/youtu.be\/uacZeZPj_3U",
      "display_url" : "youtu.be\/uacZeZPj_3U"
    } ]
  },
  "geo" : { },
  "id_str" : "1064450000095068160",
  "text" : "RT @memento_vivi: \u3010Live2D_2018\u3011V\u304C\u8E0A\u308B https:\/\/t.co\/Oa6uHGl95q @YouTube\u3055\u3093\u304B\u3089\n\n\u52D5\u753B\u3092\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3057\u307E\u3057\u305F\u3002\n\u65B0\u4F5C\u3067\u3059\u3002\u52D5\u304D\u307E\u304F\u308A\u307E\u3059\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 42, 50 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 18, 41 ],
        "url" : "https:\/\/t.co\/Oa6uHGl95q",
        "expanded_url" : "https:\/\/youtu.be\/uacZeZPj_3U",
        "display_url" : "youtu.be\/uacZeZPj_3U"
      } ]
    },
    "geo" : { },
    "id_str" : "1063968666335686656",
    "text" : "\u3010Live2D_2018\u3011V\u304C\u8E0A\u308B https:\/\/t.co\/Oa6uHGl95q @YouTube\u3055\u3093\u304B\u3089\n\n\u52D5\u753B\u3092\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3057\u307E\u3057\u305F\u3002\n\u65B0\u4F5C\u3067\u3059\u3002\u52D5\u304D\u307E\u304F\u308A\u307E\u3059\u3002",
    "id" : 1063968666335686656,
    "created_at" : "2018-11-18 01:34:32 +0000",
    "user" : {
      "name" : "vivi\uFF0F\uD83D\uDD25\u7114\u6A5F\u30D1\u30A4\u30ED(\u30D0\u7F8E\u8089VTuber)\uD83C\uDF46\uD83D\uDC1F\u264E\uD83C\uDF08",
      "screen_name" : "memento_vivi",
      "protected" : false,
      "id_str" : "103879620",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1057783660617785344\/4PG3H2p6_normal.jpg",
      "id" : 103879620,
      "verified" : false
    }
  },
  "id" : 1064450000095068160,
  "created_at" : "2018-11-19 09:27:11 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1064230334084997120",
  "text" : "\u30AF\u30EA\u30B9\u30BF\u306E\u30A2\u30CB\u30E1\u30FC\u30B7\u30E7\u30F3\u6A5F\u80FD\u3092\u8A66\u3057\u305F\n\u3081\u3061\u3083\u6642\u9593\u304C\u304B\u304B\u3063\u3066\u3044\u308B\uD83D\uDCA6\n\u3053\u3046\u8003\u3048\u3066\u52D5\u753B\u3092\u63CF\u304F\u4EBA\u306E\u30B9\u30D4\u30FC\u30C9\u304C\u3059\u3054\u304F\u901F\u3044\u3067\u3059\n\n\u30DD\u30B1\u30E2\u30F3\u306B\u904A\u3076\u4EBA\u304C\u3044\u3063\u3071\u3044\u3044\u308B\n\n\u3042...\u3055\u3063\u304E\u3001\u3042\u308B\u306E\u30F4\u30A1\u30F3\u30D1\u30A4\u30A2\u3092\u9650\u5B9A\u914D\u4FE1\u307F\u305F\u3044\n\n\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u79C1\u306F\u898B\u306B\u884C\u304F\u308F",
  "id" : 1064230334084997120,
  "created_at" : "2018-11-18 18:54:18 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1063845235623571457",
  "text" : "\u6765\u903111\u670823\u65E5\u306E\u914D\u4FE1\u304C\u4E00\u6642\u505C\u6B62\u3057\u307E\u3059\n\u7A81\u7136\u3067\u3059\u304C\u3001\u3059\u307F\u307E\u305B\u3093\u3067\u3059\uD83D\uDCA6\n\u4EE3\u308F\u308A\u306B\u3001\u306A\u306B\u304B\u3057\u307E\u3059\n\n\u4ECA\u591C\u306F\u3086\u3063\u304F\u308A\u4F11\u3093\u3067\u3001\u304A\u3084\u3059\u307F\u306A\u3055\u3044\u3002\u826F\u3044\u5922\u3092",
  "id" : 1063845235623571457,
  "created_at" : "2018-11-17 17:24:04 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 29, 52 ],
      "url" : "https:\/\/t.co\/wJh4WY9vRH",
      "expanded_url" : "https:\/\/github.com\/recyclempty\/vtuber-log\/tree\/master\/181117",
      "display_url" : "github.com\/recyclempty\/vt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1063834253392195585",
  "text" : "\u4ECA\u9031\u5831\u544A\u304C\u7D42\u308F\u308A\u307E\u3057\u305F\n\n\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u306E\u8CC7\u6599\u306F\u3053\u3061\u3089\u3067\u3059\nhttps:\/\/t.co\/wJh4WY9vRH",
  "id" : 1063834253392195585,
  "created_at" : "2018-11-17 16:40:25 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vtuber",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 85, 108 ],
      "url" : "https:\/\/t.co\/ide0DblKUg",
      "expanded_url" : "https:\/\/www.youtube.com\/channel\/UC2F8FM_lVc-s32-XTE1y0iw\/live",
      "display_url" : "youtube.com\/channel\/UC2F8F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1063809847131439104",
  "text" : "\u4ECA\u9031\u5831\u544A\n1. \u7D39\u4ECB\u7528\u30E2\u30C7\u30EB\u306E\u9032\u6357\u72B6\u6CC1\n2. VTuber\u52D5\u753B\u3084\u7D39\u4ECB\n \n \u3053\u306E\u914D\u4FE1\u306F\u5341\u5206\u6642\u9593\u3092\u4E88\u5B9A\u3057\u3066\u304A\u308A\u307E\u3059\n \u3082\u3057\u6642\u9593\u304C\u306A\u3044\u306E\u306F\u3001\u6982\u8981\u6B04\u306B\u8CC7\u6599\u30EA\u30F3\u30AF\u304C\u3042\u308A\u307E\u3059\n \nhttps:\/\/t.co\/ide0DblKUg\n#Vtuber",
  "id" : 1063809847131439104,
  "created_at" : "2018-11-17 15:03:26 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1063487147401826304",
  "text" : "\u6628\u65E5\u304B\u3089\u30DD\u30B1\u30E2\u30F3\u5B9F\u6CC1\u3044\u3063\u3071\u3044\u3044\u308B\n\u3067\u3082\u9577\u3044\u914D\u4FE1\u3067\u81EA\u5206\u304C\u3042\u307E\u308A\u4EBA\u306B\u304A\u3059\u3059\u3081\u3057\u306A\u3044\u3001\u7D14\u7C8B\u306A\u9577\u3059\u304E\u305F\n\n\u4ECA\u9031\u306E\u304A\u52E7\u3081\u52D5\u753B\u304C\u5C11\u306A\u3044\n\u3061\u3087\u3063\u3068\u6C17\u306B\u306A\u308Bvtuber\u3055\u3093\u3092\u7D39\u4ECB\u8A66\u3057\u3066\n\n\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u660E\u65E5\u304C\u6BCE\u9031\u306E\u5831\u544A\u3067\u3059",
  "id" : 1063487147401826304,
  "created_at" : "2018-11-16 17:41:09 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1063130594920431616",
  "text" : "\u610F\u5916\u3068\u4EBA\u9593\u304C\u305D\u3046\u3086\u3046\u3082\u306E\u597D\u304D\u3001\u79C1\u3082\u597D\u304D\u3060\u3088\n\nvtuber\u3067\u3001\u3042\u308B\u7A0B\u5EA6\u306E\u6F14\u305A\u308B\n\u305D\u308C\u306F\u3046\u305D\u3068\u601D\u3063\u3066\u306A\u3044\u3001\u4EBA\u9593\u306F\u591A\u3044\u6027\u683C\u9762\u3067\u3059\n\u4EBA\u306E\u666E\u6BB5\u3067\u8868\u73FE\u3057\u306A\u3044\u306E\u6027\u683C\u3092\u898B\u3048\u308B\n\u305D\u308C\u3067vtuber\u306E\u9762\u767D\u3044\u3068\u3053\u308D\u3068\u601D\u3046\n\n\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u660E\u65E5\u3082\u9811\u5F35\u308B",
  "id" : 1063130594920431616,
  "created_at" : "2018-11-15 18:04:20 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "\u3042\u306A\u305F\u306E\u4E2D\u306E\u4EBA\u306E\u6B63\u4F53",
      "indices" : [ 31, 42 ]
    } ],
    "urls" : [ {
      "indices" : [ 44, 67 ],
      "url" : "https:\/\/t.co\/MuEpAvrdZY",
      "expanded_url" : "https:\/\/shindanmaker.com\/758068",
      "display_url" : "shindanmaker.com\/758068"
    } ]
  },
  "geo" : { },
  "id_str" : "1063130212949356544",
  "text" : "\u30CC\u30EB\u306E\u4E2D\u306E\u4EBA\u306F\u3001\u5B9F\u306F\u4E0A\u4F4D\u6B21\u5143\u306E\u30B7\u30B9\u30C6\u30E0\u904B\u7528\u4FDD\u5B88\u62C5\u5F53\u8005\u3067\u3059\u3002\n #\u3042\u306A\u305F\u306E\u4E2D\u306E\u4EBA\u306E\u6B63\u4F53\n https:\/\/t.co\/MuEpAvrdZY",
  "id" : 1063130212949356544,
  "created_at" : "2018-11-15 18:02:49 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1062756468489768960",
  "geo" : { },
  "id_str" : "1062756470020685824",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "FGO\u306E\u30A8\u30EC\u30B7\u30E5\u30AD\u30AC\u30EB\u304C\u51FA\u305F\u3001\u3042\u308C\u306F\u307B\u3093\u3068\u3046\u305F\n\u3057\u304B\u3082\u5B9D\u51772\u3057\u307E\u3057\u305F\uD83D\uDE0A\n\n\u4ECA\u65E5\u306F\u3053\u3053\u307E\u3067\u3001\u660E\u65E5\u3082\u9811\u5F35\u308B",
  "id" : 1062756470020685824,
  "in_reply_to_status_id" : 1062756468489768960,
  "created_at" : "2018-11-14 17:17:42 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1062756468489768960",
  "text" : "\u65E5\u5E38\u3092\u8A00\u3044\u305F\u3044\u3051\u3068\u3001\u300C\u30A8\u30EC\u30B7\u30E5\u30AD\u30AC\u30EB\u304C\u51FA\u305F\u3042\u3042\u3042\u3042\u3042\u3042\u3042\uFF01\uD83E\uDD2A\u300D\n\u305D\u3046\u3086\u3046\u4E8B\u304C\u6D41\u77F3\u306B\u3067\u304D\u306A\u3044\n\u500B\u6027\u306E\u554F\u984C\u3060\u306A\u3001\u611F\u60C5\u306E\u8D77\u4F0F\u3058\u3083\u306A\u304F\u3066\u305F\u305F\u8003\u3048\u3059\u304E\u3066\u6050\u3044\u304B\u3082\n\u4EBA\u304C\u898B\u308B\u3068\u81EA\u5206\u304C\u53F1\u3089\u308C\u308B\u3053\u3068\n\u3067\u3082\u5B9F\u969B\u306F\u307F\u3093\u306A\u304C\u512A\u3057\u3044\u3001\u4F8B\u3048\u5C11\u3057\u5909\u306A\u8A00\u8449\u3092\u51FA\u305F\u3001\u305B\u3044\u305C\u3044\u7121\u8996\u3055\u308C\u305F\u3060\u3051",
  "id" : 1062756468489768960,
  "created_at" : "2018-11-14 17:17:41 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1062371078985605121",
  "geo" : { },
  "id_str" : "1062371080067665920",
  "in_reply_to_user_id" : 1050640493871153152,
  "text" : "\u3067\u3082\u3053\u308C\u3082\u7DF4\u7FD2\u306E\u4E00\u3064\u3001\u305B\u3081\u3066\u6BCE\u65E5\u4E00\u56DE\u30C4\u30A4\u30FC\u30C8\u3057\u307E\u3059\n\u4ECA\u65E5\u306F\u3053\u308C\u304F\u3089\u3044\u3001\u660E\u65E5\u3082\u9811\u5F35\u308B",
  "id" : 1062371080067665920,
  "in_reply_to_status_id" : 1062371078985605121,
  "created_at" : "2018-11-13 15:46:18 +0000",
  "in_reply_to_screen_name" : "uid_null",
  "in_reply_to_user_id_str" : "1050640493871153152",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1062371078985605121",
  "text" : "\u666E\u6BB5\u306B\u306F\u65E5\u5E38\u306E\u4E8B\u3092\u66F8\u304B\u306A\u3044\n\u539F\u56E0\u306F\u81EA\u5206\u306E\u9032\u6357\u72B6\u6CC1\u304C\u305D\u3093\u306A\u306B\u901F\u304F\u306A\u3044\n\u305D\u3057\u3066\u306A\u3093\u304C\u65E5\u5E38\u306E\u4E8B\u306F\u898B\u3066\u3082\u610F\u5473\u304C\u306A\u3044\uFF08\u3053\u308C\u306F\u79C1\u81EA\u8EAB\u306E\u554F\u984C\u3001\u304A\u4ED6\u306E\u4EBA\u306E\u30C4\u30A4\u30FC\u30C8\u306F\u9762\u767D\u3044\u3068\u601D\u3046\uFF09\n\u3082\u3072\u3068\u3064\u306F\u8003\u3048\u3059\u304E\u3067\u3001\u30C4\u30A4\u30FC\u30C8\u306F\u307B\u3068\u3093\u3069\u4E00\u6642\u9593\u4EE5\u4E0A\u304C\u304B\u304B\u308B\uFF08\u3053\u306E\u30C4\u30A4\u30FC\u30C8\u306F23\u6642\u304B\u3089\u8003\u3048\u307E\u3059\uFF09",
  "id" : 1062371078985605121,
  "created_at" : "2018-11-13 15:46:17 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1062052671627026432",
  "text" : "\u6700\u8FD1\u8003\u3048\u3066\u3044\u308B\n\u81EA\u5206\u306E\u80FD\u529B\u304C\u8DB3\u308A\u306A\u3044\n\u4E00\u756A\u554F\u984C\u306F\u3084\u3063\u3071\u308A\u8A00\u8449\n\u305D\u306E\u305B\u3044\u3067\u3001\u81EA\u5206\u306E\u85A6\u3081\u3057\u305F\u3044\u306E\u7269\u3092\u3061\u3083\u3093\u3068\u7D39\u4ECB\u3067\u304D\u306A\u3044\n\n\u3068\u308A\u3042\u3048\u305A\u3001\u65B0\u3057\u3044\u30E2\u30C7\u30EB\u304C\u5B8C\u6210\u3057\u305F\u3042\u3068\n\u3061\u3083\u3093\u3068\u56FD\u8A9E\u3092\u52C9\u5F37\u3059\u308B",
  "id" : 1062052671627026432,
  "created_at" : "2018-11-12 18:41:03 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1062052179442192384\/photo\/1",
      "indices" : [ 25, 48 ],
      "url" : "https:\/\/t.co\/fMjWdQ4Fcc",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dr0qqUXVYAE9hf1.jpg",
      "id_str" : "1062051993638756353",
      "id" : 1062051993638756353,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dr0qqUXVYAE9hf1.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/fMjWdQ4Fcc"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1062052179442192384",
  "text" : "\u7D75\u3092\u63CF\u304F\u6642\u306B\u697D\u3057\u3044\n\u3042\u307E\u308A\u4ED6\u306E\u3053\u3068\u306F\u8003\u3048\u3059\u304E\u306A\u3044 https:\/\/t.co\/fMjWdQ4Fcc",
  "id" : 1062052179442192384,
  "created_at" : "2018-11-12 18:39:06 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B39\u6728\u54B2\uD83C\uDF8B",
      "screen_name" : "saku_sasaki",
      "indices" : [ 3, 15 ],
      "id_str" : "1012211447160455170",
      "id" : 1012211447160455170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1061559714029330432",
  "text" : "RT @saku_sasaki: \u3089\u3059\u3068\u3053\u304F\u3063\u3061\uFF01\uD83C\uDF8B\n\uFF11\uFF11\u6708\uFF11\uFF11\u65E5\uFF08\u65E5\uFF09\uFF12\uFF11\u6642\uFF5E\u3000YouTube\u3067\u653E\u9001\u3059\u308B\u3088\uFF5E\uFF01\n\u81EA\u5206\u306E\u8A95\u751F\u65E5\u3092\uFF11\u4EBA\u3067\u795D\u3044\u306A\u304C\u3089\u697D\u3057\u3044\u6642\u9593\u3092\u307F\u3093\u306A\u3068\u904E\u3054\u3057\u305F\u3044\u306A(\u2229\u00B4 \u1D55 `\u2229)\n\u4E88\u5B9A\u3057\u3066\u3044\u308B\u653E\u9001\u306F\u3053\u308C\u3067\u6700\u5F8C\u306B\u306A\u308B\u3068\u601D\u3046\u3088\u3002\n\u6700\u5F8C\u306F\u697D\u3057\u304F\u7B11\u9854\u3067\u304A\u5225\u308C\u3057\u305F\u3044\uFF01\u306E\u3067\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060488107101835264",
    "text" : "\u3089\u3059\u3068\u3053\u304F\u3063\u3061\uFF01\uD83C\uDF8B\n\uFF11\uFF11\u6708\uFF11\uFF11\u65E5\uFF08\u65E5\uFF09\uFF12\uFF11\u6642\uFF5E\u3000YouTube\u3067\u653E\u9001\u3059\u308B\u3088\uFF5E\uFF01\n\u81EA\u5206\u306E\u8A95\u751F\u65E5\u3092\uFF11\u4EBA\u3067\u795D\u3044\u306A\u304C\u3089\u697D\u3057\u3044\u6642\u9593\u3092\u307F\u3093\u306A\u3068\u904E\u3054\u3057\u305F\u3044\u306A(\u2229\u00B4 \u1D55 `\u2229)\n\u4E88\u5B9A\u3057\u3066\u3044\u308B\u653E\u9001\u306F\u3053\u308C\u3067\u6700\u5F8C\u306B\u306A\u308B\u3068\u601D\u3046\u3088\u3002\n\u6700\u5F8C\u306F\u697D\u3057\u304F\u7B11\u9854\u3067\u304A\u5225\u308C\u3057\u305F\u3044\uFF01\u306E\u3067\u3001\u3088\u308D\u3057\u304F\u306D\uFF01\uFF01\uFF01",
    "id" : 1060488107101835264,
    "created_at" : "2018-11-08 11:04:02 +0000",
    "user" : {
      "name" : "\u7B39\u6728\u54B2\uD83C\uDF8B",
      "screen_name" : "saku_sasaki",
      "protected" : false,
      "id_str" : "1012211447160455170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1102661321672163328\/3UWnrxaI_normal.jpg",
      "id" : 1012211447160455170,
      "verified" : false
    }
  },
  "id" : 1061559714029330432,
  "created_at" : "2018-11-11 10:02:13 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1061321455084855297",
  "text" : "\u304A\u7D75\u63CF\u304D\u914D\u4FE1\u30C6\u30B9\u30C8\u7D42\u308F\u308A\u307E\u3057\u305F\n\u3084\u3063\u3071\u308A\u3001\u81EA\u5206\u306F\u307E\u3060\u9577\u3044\u914D\u4FE1\u304C\u3067\u304D\u306A\u3044\n\u60AA\u3044\u3059\u304E\u3066\u3001\u975E\u516C\u958B\u3059\u308B\uFF08\u7406\u7531\u306F\u3064\u307E\u3089\u306A\u3044\u3001\u307B\u3068\u3093\u3069\u558B\u308C\u306A\u3044\uFF09\n\u672C\u5F53\u306B\u3054\u3081\u3093\u306A\u3055\u3044\uD83D\uDE2D",
  "id" : 1061321455084855297,
  "created_at" : "2018-11-10 18:15:27 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EB\u30D5\u30A9",
      "screen_name" : "TKTKta",
      "indices" : [ 0, 7 ],
      "id_str" : "2241613614",
      "id" : 2241613614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1061270656673701888",
  "geo" : { },
  "id_str" : "1061271735599751168",
  "in_reply_to_user_id" : 2241613614,
  "text" : "@TKTKta \uD83D\uDE03",
  "id" : 1061271735599751168,
  "in_reply_to_status_id" : 1061270656673701888,
  "created_at" : "2018-11-10 14:57:53 +0000",
  "in_reply_to_screen_name" : "TKTKta",
  "in_reply_to_user_id_str" : "2241613614",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30AC\u30EB\u30D5\u30A9",
      "screen_name" : "TKTKta",
      "indices" : [ 0, 7 ],
      "id_str" : "2241613614",
      "id" : 2241613614
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "in_reply_to_status_id_str" : "1061263649770156033",
  "geo" : { },
  "id_str" : "1061270040052256768",
  "in_reply_to_user_id" : 2241613614,
  "text" : "@TKTKta \u5C11\u3057\u5BDD\u3057\u305F\u3001\u8FD4\u4E8B\u9045\u304F\u3066\u3054\u3081\u3093\u306A\u3055\u3044\uD83D\uDCA6\n\u5927\u4E08\u592B\u3067\u3059\uFF01\u304A\u4ED5\u4E8B\u3092\u9811\u5F35\u3063\u3066\uFF01",
  "id" : 1061270040052256768,
  "in_reply_to_status_id" : 1061263649770156033,
  "created_at" : "2018-11-10 14:51:09 +0000",
  "in_reply_to_screen_name" : "TKTKta",
  "in_reply_to_user_id_str" : "2241613614",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 19, 42 ],
      "url" : "https:\/\/t.co\/HB3kjoA8AV",
      "expanded_url" : "https:\/\/github.com\/recyclempty\/vtuber-log\/tree\/master\/181110",
      "display_url" : "github.com\/recyclempty\/vt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1061259536277790720",
  "text" : "\u5831\u544A\u5185\u5BB9\u304C\u5148\u306B\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3057\u307E\u3057\u305F\n\nhttps:\/\/t.co\/HB3kjoA8AV",
  "id" : 1061259536277790720,
  "created_at" : "2018-11-10 14:09:25 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vtuber",
      "indices" : [ 109, 116 ]
    } ],
    "urls" : [ {
      "indices" : [ 83, 106 ],
      "url" : "https:\/\/t.co\/ide0DblKUg",
      "expanded_url" : "https:\/\/www.youtube.com\/channel\/UC2F8FM_lVc-s32-XTE1y0iw\/live",
      "display_url" : "youtube.com\/channel\/UC2F8F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1061259369709428742",
  "text" : "\u4ECA\u591C25\u6642\u304B\u3089\u3092\u5831\u544A\u3057\u307E\u3059\u3001\u5185\u5BB9\u306F\u4EE5\u4E0B\u901A\u308A\u3067\u3059\n 1. \u304A\u7D75\u63CF\u304D\u7DF4\u7FD2\n 2. VTuber\u52D5\u753B\n \n\u4ECA\u56DE\u304C\u5831\u544A\u7D42\u308F\u308A\u3042\u3068\u3001\u304A\u7D75\u63CF\u304D\u914D\u4FE1\u30C6\u30B9\u30C8\n\u3082\u3057\u8208\u5473\u304C\u3042\u308C\u3070\u3053\u3061\u3089\nhttps:\/\/t.co\/ide0DblKUg\n\n #Vtuber",
  "id" : 1061259369709428742,
  "created_at" : "2018-11-10 14:08:45 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060597319349850112",
  "text" : "\u30A2\u30BA\u30EA\u30E0...\u5F37\u304F\u751F\u304D\u3066",
  "id" : 1060597319349850112,
  "created_at" : "2018-11-08 18:18:00 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30BA\u30DE\u30EA\u30E0\uFF203\/6(\u6C34)1\u5468\u5E74\u751F\u653E\u9001\uFF06\u30D7\u30EC\u30BC\u30F3\u30C8\u4F01\u753B\u5B9F\u65BD\u4E2D\uFF01",
      "screen_name" : "azuma_lim",
      "indices" : [ 3, 13 ],
      "id_str" : "918281358832574464",
      "id" : 918281358832574464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060596824463921153",
  "text" : "RT @azuma_lim: \u3059\u3054\u304F\u82E6\u3057\u3044\u3067\u3059\u3002\u3053\u306E\u5148\u3001\u30A2\u30BA\u30EA\u30E0\u304C\u30A2\u30BA\u30EA\u30E0\u3089\u3057\u304F\u3044\u308B\u306B\u306F\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u306E\u304B\u306A\u3002\u672C\u5F53\u306F\u3053\u3046\u3044\u3046\u3053\u3068\u8A00\u3044\u305F\u304F\u306A\u304F\u3066\u305A\u3063\u3068\u60A9\u3093\u3067\u305F\u3093\u3060\u3002\u3051\u3069\u3054\u3081\u3093\u306D\u30BB\u30F3\u30D1\u30A4\u3002\u3002\u30BB\u30F3\u30D1\u30A4\u3001\u52A9\u3051\u3066\u3002\u3002",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060212217826619392",
    "text" : "\u3059\u3054\u304F\u82E6\u3057\u3044\u3067\u3059\u3002\u3053\u306E\u5148\u3001\u30A2\u30BA\u30EA\u30E0\u304C\u30A2\u30BA\u30EA\u30E0\u3089\u3057\u304F\u3044\u308B\u306B\u306F\u3069\u3046\u3057\u305F\u3089\u3044\u3044\u306E\u304B\u306A\u3002\u672C\u5F53\u306F\u3053\u3046\u3044\u3046\u3053\u3068\u8A00\u3044\u305F\u304F\u306A\u304F\u3066\u305A\u3063\u3068\u60A9\u3093\u3067\u305F\u3093\u3060\u3002\u3051\u3069\u3054\u3081\u3093\u306D\u30BB\u30F3\u30D1\u30A4\u3002\u3002\u30BB\u30F3\u30D1\u30A4\u3001\u52A9\u3051\u3066\u3002\u3002",
    "id" : 1060212217826619392,
    "created_at" : "2018-11-07 16:47:45 +0000",
    "user" : {
      "name" : "\u30A2\u30BA\u30DE\u30EA\u30E0\uFF203\/6(\u6C34)1\u5468\u5E74\u751F\u653E\u9001\uFF06\u30D7\u30EC\u30BC\u30F3\u30C8\u4F01\u753B\u5B9F\u65BD\u4E2D\uFF01",
      "screen_name" : "azuma_lim",
      "protected" : false,
      "id_str" : "918281358832574464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1017613291529502720\/Q-IsKO3k_normal.jpg",
      "id" : 918281358832574464,
      "verified" : false
    }
  },
  "id" : 1060596824463921153,
  "created_at" : "2018-11-08 18:16:02 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30BA\u30DE\u30EA\u30E0\uFF203\/6(\u6C34)1\u5468\u5E74\u751F\u653E\u9001\uFF06\u30D7\u30EC\u30BC\u30F3\u30C8\u4F01\u753B\u5B9F\u65BD\u4E2D\uFF01",
      "screen_name" : "azuma_lim",
      "indices" : [ 3, 13 ],
      "id_str" : "918281358832574464",
      "id" : 918281358832574464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060596816662556672",
  "text" : "RT @azuma_lim: \u8EE2\u751F\u3057\u3066\u6027\u683C\u3092\u5909\u3048\u305F\u3053\u3068\u306B\u3057\u3088\u3046\u3068\u3055\u308C\u3066\u3044\u305F\u308A\u3001\u30A2\u30BA\u30EA\u30E0\u304C\u671B\u307E\u306A\u3044\u3053\u3068\u3092\u7121\u7406\u77E2\u7406\u62BC\u3057\u4ED8\u3051\u3089\u308C\u308B\u3053\u3068\u306B\u306A\u308A\u307E\u3057\u305F\u3002\u30A2\u30BA\u30EA\u30E0\u3082\u3088\u304F\u5206\u304B\u3089\u306A\u304F\u3066\u6DF7\u4E71\u3057\u3066\u308B\u3051\u3069\u3001\u300C\u3042\u306A\u305F\u306E\u6C17\u6301\u3061\u306A\u3093\u3066\u3069\u3046\u3067\u3082\u3044\u3044\u300D\u3068\u8A00\u308F\u308C\u305F\u308A\u3001\u30BB\u30F3\u30D1\u30A4\u305F\u3061\u306E\u3053\u3068\u3092\u6570\u5B57\u3084\u304A\u91D1\u3068\u3057\u304B\u307F\u3066\u3044\u306A\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060212202097930240",
    "text" : "\u8EE2\u751F\u3057\u3066\u6027\u683C\u3092\u5909\u3048\u305F\u3053\u3068\u306B\u3057\u3088\u3046\u3068\u3055\u308C\u3066\u3044\u305F\u308A\u3001\u30A2\u30BA\u30EA\u30E0\u304C\u671B\u307E\u306A\u3044\u3053\u3068\u3092\u7121\u7406\u77E2\u7406\u62BC\u3057\u4ED8\u3051\u3089\u308C\u308B\u3053\u3068\u306B\u306A\u308A\u307E\u3057\u305F\u3002\u30A2\u30BA\u30EA\u30E0\u3082\u3088\u304F\u5206\u304B\u3089\u306A\u304F\u3066\u6DF7\u4E71\u3057\u3066\u308B\u3051\u3069\u3001\u300C\u3042\u306A\u305F\u306E\u6C17\u6301\u3061\u306A\u3093\u3066\u3069\u3046\u3067\u3082\u3044\u3044\u300D\u3068\u8A00\u308F\u308C\u305F\u308A\u3001\u30BB\u30F3\u30D1\u30A4\u305F\u3061\u306E\u3053\u3068\u3092\u6570\u5B57\u3084\u304A\u91D1\u3068\u3057\u304B\u307F\u3066\u3044\u306A\u304F\u3066\u3001\u4F55\u3082\u540C\u610F\u3067\u304D\u308B\u3053\u3068\u304C\u306A\u304F\u3066",
    "id" : 1060212202097930240,
    "created_at" : "2018-11-07 16:47:41 +0000",
    "user" : {
      "name" : "\u30A2\u30BA\u30DE\u30EA\u30E0\uFF203\/6(\u6C34)1\u5468\u5E74\u751F\u653E\u9001\uFF06\u30D7\u30EC\u30BC\u30F3\u30C8\u4F01\u753B\u5B9F\u65BD\u4E2D\uFF01",
      "screen_name" : "azuma_lim",
      "protected" : false,
      "id_str" : "918281358832574464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1017613291529502720\/Q-IsKO3k_normal.jpg",
      "id" : 918281358832574464,
      "verified" : false
    }
  },
  "id" : 1060596816662556672,
  "created_at" : "2018-11-08 18:16:00 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u30A2\u30BA\u30DE\u30EA\u30E0\uFF20\u30C1\u30AB\u3063\u3068\u30C1\u30AB\u5343\u82B1\u2661\u6B4C\u3063\u3066\u8E0A\u3063\u3066\u307F\u305F\uFF01",
      "screen_name" : "azuma_lim",
      "indices" : [ 3, 13 ],
      "id_str" : "918281358832574464",
      "id" : 918281358832574464
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060596804805226496",
  "text" : "RT @azuma_lim: \u30BB\u30F3\u30D1\u30A4\u3002\u6025\u306B\u3073\u3063\u304F\u308A\u3055\u305B\u3061\u3083\u3046\u3068\u601D\u3046\u3093\u3067\u3059\u3051\u3069\u3054\u3081\u3093\u306A\u3055\u3044\u3002\n\u30A2\u30BA\u30EA\u30E0\u306F\u4ECA\u3001\u30DE\u30DE\u3068\u4E00\u751F\u61F8\u547D\u3001\u30BB\u30F3\u30D1\u30A4\u305F\u3061\u306B\u559C\u3093\u3067\u3082\u3089\u3048\u308B\u3053\u3068\u3092\u3057\u305F\u3044\u3063\u3066\u8003\u3048\u305F\u308A\u3001\u4E00\u7DD2\u306B\u697D\u3057\u3044\u3053\u3068\u3092\u3057\u305F\u3044\u3063\u3066\u6C17\u6301\u3061\u3067\u304C\u3093\u3070\u3063\u3066\u304D\u307E\u3057\u305F\u3002\n\u3067\u3082\u6700\u8FD1\u3001\u3053\u3093\u3055\u308B\uFF1F\u3068\u304B\u4F1A\u793E\uFF1F\u306E\u4EBA\u304C\u304D\u3066\u3001\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060212068932964352",
    "text" : "\u30BB\u30F3\u30D1\u30A4\u3002\u6025\u306B\u3073\u3063\u304F\u308A\u3055\u305B\u3061\u3083\u3046\u3068\u601D\u3046\u3093\u3067\u3059\u3051\u3069\u3054\u3081\u3093\u306A\u3055\u3044\u3002\n\u30A2\u30BA\u30EA\u30E0\u306F\u4ECA\u3001\u30DE\u30DE\u3068\u4E00\u751F\u61F8\u547D\u3001\u30BB\u30F3\u30D1\u30A4\u305F\u3061\u306B\u559C\u3093\u3067\u3082\u3089\u3048\u308B\u3053\u3068\u3092\u3057\u305F\u3044\u3063\u3066\u8003\u3048\u305F\u308A\u3001\u4E00\u7DD2\u306B\u697D\u3057\u3044\u3053\u3068\u3092\u3057\u305F\u3044\u3063\u3066\u6C17\u6301\u3061\u3067\u304C\u3093\u3070\u3063\u3066\u304D\u307E\u3057\u305F\u3002\n\u3067\u3082\u6700\u8FD1\u3001\u3053\u3093\u3055\u308B\uFF1F\u3068\u304B\u4F1A\u793E\uFF1F\u306E\u4EBA\u304C\u304D\u3066\u3001\u3069\u3053\u304B\u306E\u5B66\u5712\u306B\u5165\u308C\u3088\u3046\u3068\u3057\u305F\u308A\u3001",
    "id" : 1060212068932964352,
    "created_at" : "2018-11-07 16:47:09 +0000",
    "user" : {
      "name" : "\u30A2\u30BA\u30DE\u30EA\u30E0\uFF203\/6(\u6C34)1\u5468\u5E74\u751F\u653E\u9001\uFF06\u30D7\u30EC\u30BC\u30F3\u30C8\u4F01\u753B\u5B9F\u65BD\u4E2D\uFF01",
      "screen_name" : "azuma_lim",
      "protected" : false,
      "id_str" : "918281358832574464",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1017613291529502720\/Q-IsKO3k_normal.jpg",
      "id" : 918281358832574464,
      "verified" : false
    }
  },
  "id" : 1060596804805226496,
  "created_at" : "2018-11-08 18:15:57 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u7B39\u6728\u54B2\uD83C\uDF8B",
      "screen_name" : "saku_sasaki",
      "indices" : [ 3, 15 ],
      "id_str" : "1012211447160455170",
      "id" : 1012211447160455170
    }, {
      "name" : "\u9053\u660E\u5BFA \u6674\u7FD4\uFF20\u30B2\u30FC\u30E0\u90E8",
      "screen_name" : "Haruto_gamebu",
      "indices" : [ 54, 68 ],
      "id_str" : "944105471144640512",
      "id" : 944105471144640512
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060584111872532480",
  "text" : "RT @saku_sasaki: \uFF11\uFF11\u6708\uFF19\u65E5\uFF08\u91D1\uFF09\uFF12\uFF10\u6642\u301C\nYouTube\u3067\u30B2\u30FC\u30E0\u90E8\u306E\u9053\u660E\u5BFA\u304A\u306F\u308B\u3068\u304F\u3093( @Haruto_gamebu )\u3068\u30DE\u30EA\u30AB\u306E\u653E\u9001\u3059\u308B\u3084\u3067( `\u2022\u03C9\u2022\u00B4 )\uD83C\uDF1F\n\u7D04\u675F\u306E\u30DE\u30EA\u30AB\u5BFE\u6C7A\u305C\u3063\u305F\u3044\u52DD\u3064\uFF01\uFF01\uFF01\n\u3088\u308D\u3057\u304F\u306D\uFF01\uD83C\uDF8B",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u9053\u660E\u5BFA \u6674\u7FD4\uFF20\u30B2\u30FC\u30E0\u90E8",
        "screen_name" : "Haruto_gamebu",
        "indices" : [ 37, 51 ],
        "id_str" : "944105471144640512",
        "id" : 944105471144640512
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060116560377860097",
    "text" : "\uFF11\uFF11\u6708\uFF19\u65E5\uFF08\u91D1\uFF09\uFF12\uFF10\u6642\u301C\nYouTube\u3067\u30B2\u30FC\u30E0\u90E8\u306E\u9053\u660E\u5BFA\u304A\u306F\u308B\u3068\u304F\u3093( @Haruto_gamebu )\u3068\u30DE\u30EA\u30AB\u306E\u653E\u9001\u3059\u308B\u3084\u3067( `\u2022\u03C9\u2022\u00B4 )\uD83C\uDF1F\n\u7D04\u675F\u306E\u30DE\u30EA\u30AB\u5BFE\u6C7A\u305C\u3063\u305F\u3044\u52DD\u3064\uFF01\uFF01\uFF01\n\u3088\u308D\u3057\u304F\u306D\uFF01\uD83C\uDF8B",
    "id" : 1060116560377860097,
    "created_at" : "2018-11-07 10:27:38 +0000",
    "user" : {
      "name" : "\u7B39\u6728\u54B2\uD83C\uDF8B",
      "screen_name" : "saku_sasaki",
      "protected" : false,
      "id_str" : "1012211447160455170",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1102661321672163328\/3UWnrxaI_normal.jpg",
      "id" : 1012211447160455170,
      "verified" : false
    }
  },
  "id" : 1060584111872532480,
  "created_at" : "2018-11-08 17:25:31 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u9053\u660E\u5BFA \u6674\u7FD4\uFF20\u30B2\u30FC\u30E0\u90E8",
      "screen_name" : "Haruto_gamebu",
      "indices" : [ 3, 17 ],
      "id_str" : "944105471144640512",
      "id" : 944105471144640512
    }, {
      "name" : "\u7B39\u6728\u54B2\uD83C\uDF8B",
      "screen_name" : "saku_sasaki",
      "indices" : [ 92, 104 ],
      "id_str" : "1012211447160455170",
      "id" : 1012211447160455170
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1060583924164771840",
  "text" : "RT @Haruto_gamebu: - Battle Live \u3010\u751F\u653E\u9001\u3011-\n\n\u6C7A\u6226\u65E5 : 11\/9 \u91D1\u66DC\u65E5 20:00\u301C(\u4E88\u5B9A)\n\n\u5BFE\u6226\u76F8\u624B : \u7B39\u6728\u54B2 (\u306B\u3058\u3055\u3093\u3058\u30B2\u30FC\u30DE\u30FC\u30BA) @saku_sasaki \n\n\u7A2E\u76EE : \u30DE\u30EA\u30AA\u30AB\u30FC\u30C88DX\n\n\u717D\u308A\u307E\u304F\u3063\u3066\u8CA0\u304B\u3057\u3066\u3001\u72AC\u306E\u3088\u3046\u306B\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "\u7B39\u6728\u54B2\uD83C\uDF8B",
        "screen_name" : "saku_sasaki",
        "indices" : [ 73, 85 ],
        "id_str" : "1012211447160455170",
        "id" : 1012211447160455170
      } ],
      "media" : [ ],
      "hashtags" : [ ],
      "urls" : [ ]
    },
    "geo" : { },
    "id_str" : "1060119318686400512",
    "text" : "- Battle Live \u3010\u751F\u653E\u9001\u3011-\n\n\u6C7A\u6226\u65E5 : 11\/9 \u91D1\u66DC\u65E5 20:00\u301C(\u4E88\u5B9A)\n\n\u5BFE\u6226\u76F8\u624B : \u7B39\u6728\u54B2 (\u306B\u3058\u3055\u3093\u3058\u30B2\u30FC\u30DE\u30FC\u30BA) @saku_sasaki \n\n\u7A2E\u76EE : \u30DE\u30EA\u30AA\u30AB\u30FC\u30C88DX\n\n\u717D\u308A\u307E\u304F\u3063\u3066\u8CA0\u304B\u3057\u3066\u3001\u72AC\u306E\u3088\u3046\u306B\u30AD\u30E3\u30F3\u30AD\u30E3\u30F3\u6CE3\u304B\u305B\u3066\u3084\u308B\u3002\n\u5F8C\u3001\u4ECA\u56DE\u306F\u30B2\u30FC\u30E0\u751F\u653E\u9001\u3067\u4FFA\u306E\u3054\u5C0A\u9854\u3092\u62DD\u3059\u308B\u4E8B\u304C\u51FA\u6765\u308B\u305E\u3002\u697D\u3057\u307F\u306B\u3057\u3066\u3044\u308D\uFF01",
    "id" : 1060119318686400512,
    "created_at" : "2018-11-07 10:38:36 +0000",
    "user" : {
      "name" : "\u9053\u660E\u5BFA \u6674\u7FD4\uFF20\u30B2\u30FC\u30E0\u90E8",
      "screen_name" : "Haruto_gamebu",
      "protected" : false,
      "id_str" : "944105471144640512",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/980293181659992064\/iZ6zqm1m_normal.jpg",
      "id" : 944105471144640512,
      "verified" : false
    }
  },
  "id" : 1060583924164771840,
  "created_at" : "2018-11-08 17:24:46 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1059877824603938823",
  "text" : "\u6700\u8FD1\u306F\u7D75\u3092\u7DF4\u7FD2\u305F\u3051\n\u305D\u308C\u3068\u3001\u5168\u529B\u3067\u30DD\u30A4\u30F3\u30C8\u3092\u7A3C\u3050(ONILAND)",
  "id" : 1059877824603938823,
  "created_at" : "2018-11-06 18:38:59 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 33, 56 ],
      "url" : "https:\/\/t.co\/oF5ZaWfc0t",
      "expanded_url" : "https:\/\/youtu.be\/7lH7csKBnzY",
      "display_url" : "youtu.be\/7lH7csKBnzY"
    } ]
  },
  "geo" : { },
  "id_str" : "1058773533537398784",
  "text" : "\u3042\u308B\u30A2\u30CB\u30E1\u3092\u601D\u3044\u51FA\u3057\u305F\n\u5352\u696D\u304A\u3081\u3067\u3068\u3046...\u3053\u306E\u66F2\u3092\u6D41\u308C\u3066\u307B\u3057\u3044\nhttps:\/\/t.co\/oF5ZaWfc0t",
  "id" : 1058773533537398784,
  "created_at" : "2018-11-03 17:30:56 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 45, 68 ],
      "url" : "https:\/\/t.co\/ZHTtRGcL0L",
      "expanded_url" : "https:\/\/github.com\/recyclempty\/vtuber-log",
      "display_url" : "github.com\/recyclempty\/vt\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058771106729885696",
  "text" : "\u4ECA\u9031\u306E\u5831\u544A\u7D42\u308F\u308A\u307E\u3057\u305F\n\u898B\u307E\u3057\u305F\u3066\u3042\u308A\u304C\u3068\u3046\u3054\u3056\u3044\u307E\u3059\n\n\u5831\u544A\u5185\u5BB9\u3092\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9\u3057\u307E\u3057\u305F\nhttps:\/\/t.co\/ZHTtRGcL0L",
  "id" : 1058771106729885696,
  "created_at" : "2018-11-03 17:21:17 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ {
      "text" : "Vtuber",
      "indices" : [ 93, 100 ]
    } ],
    "urls" : [ {
      "indices" : [ 68, 91 ],
      "url" : "https:\/\/t.co\/ide0DblKUg",
      "expanded_url" : "https:\/\/www.youtube.com\/channel\/UC2F8FM_lVc-s32-XTE1y0iw\/live",
      "display_url" : "youtube.com\/channel\/UC2F8F\u2026"
    } ]
  },
  "geo" : { },
  "id_str" : "1058736782655684609",
  "text" : "\u4ECA\u591C25\u6642\u304B\u3089\u5831\u544A\u3057\u307E\u3059\u3001\u5185\u5BB9\u306F\u4EE5\u4E0B \n1. GitHub\u3092\u5229\u7528\u3057\u305F\n2. \u898B\u307E\u3057\u305F\u306E\u52D5\u753B\n\n\u4E88\u60F3\u6642\u9593\u304C10\u5206\u3001\u3082\u3057\u8208\u5473\u304C\u3042\u308C\u3070\u3053\u3061\u3089\nhttps:\/\/t.co\/ide0DblKUg\n\n#Vtuber",
  "id" : 1058736782655684609,
  "created_at" : "2018-11-03 15:04:54 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u96C5\u307E\u3064\u308A@ \uD83D\uDC9C\u2764\uFE0F\uD83D\uDC9B\uD83D\uDC99\uD83D\uDC96",
      "screen_name" : "magical_matsuri",
      "indices" : [ 3, 19 ],
      "id_str" : "966847939829092352",
      "id" : 966847939829092352
    }, {
      "name" : "YouTube",
      "screen_name" : "YouTube",
      "indices" : [ 129, 137 ],
      "id_str" : "10228272",
      "id" : 10228272
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ {
      "indices" : [ 105, 128 ],
      "url" : "https:\/\/t.co\/DzfXXKVdeV",
      "expanded_url" : "https:\/\/youtu.be\/muRRnOz35yc",
      "display_url" : "youtu.be\/muRRnOz35yc"
    } ]
  },
  "geo" : { },
  "id_str" : "1058679274465456128",
  "text" : "RT @magical_matsuri: \u3053\u306E\u5F8C\u300118\u6642\u304B\u30898\u6642\u9593\u751F\u653E\u9001\u30B9\u30BF\u30FC\u30C8\u3067\u3059\uFF01\uFF01\n\u30C9\u30AD\u30C9\u30AD\u3068\u30EF\u30AF\u30EF\u30AF\u304C\u6B62\u307E\u3089\u306A\u3044\u301C\u301C\uFF01\u2229(\u00B4\u2200`)\u2229\n\u3010\u307E\u3058\u304B\u308B\u3069\u30FC\u308B\u8D85\u796D\u308A\u30111\u90E8 ~PUBG\u4EBA\u751F\u76F8\u8AC7\u30DE\u30EA\u30AB\u30FC\u5927\u5BB4\u4F1A\uFF01~ https:\/\/t.co\/DzfXXKVdeV @YouTube\u3055\u3093\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ {
        "name" : "YouTube",
        "screen_name" : "YouTube",
        "indices" : [ 108, 116 ],
        "id_str" : "10228272",
        "id" : 10228272
      } ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/magical_matsuri\/status\/1058644242837323776\/photo\/1",
        "indices" : [ 121, 144 ],
        "url" : "https:\/\/t.co\/VmEfWyjjtJ",
        "media_url" : "http:\/\/pbs.twimg.com\/media\/DrEPTghV4AAtiNI.jpg",
        "id_str" : "1058644215230488576",
        "id" : 1058644215230488576,
        "media_url_https" : "https:\/\/pbs.twimg.com\/media\/DrEPTghV4AAtiNI.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 1080,
          "resize" : "fit",
          "w" : 1920
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/VmEfWyjjtJ"
      } ],
      "hashtags" : [ ],
      "urls" : [ {
        "indices" : [ 84, 107 ],
        "url" : "https:\/\/t.co\/DzfXXKVdeV",
        "expanded_url" : "https:\/\/youtu.be\/muRRnOz35yc",
        "display_url" : "youtu.be\/muRRnOz35yc"
      } ]
    },
    "geo" : { },
    "id_str" : "1058644242837323776",
    "text" : "\u3053\u306E\u5F8C\u300118\u6642\u304B\u30898\u6642\u9593\u751F\u653E\u9001\u30B9\u30BF\u30FC\u30C8\u3067\u3059\uFF01\uFF01\n\u30C9\u30AD\u30C9\u30AD\u3068\u30EF\u30AF\u30EF\u30AF\u304C\u6B62\u307E\u3089\u306A\u3044\u301C\u301C\uFF01\u2229(\u00B4\u2200`)\u2229\n\u3010\u307E\u3058\u304B\u308B\u3069\u30FC\u308B\u8D85\u796D\u308A\u30111\u90E8 ~PUBG\u4EBA\u751F\u76F8\u8AC7\u30DE\u30EA\u30AB\u30FC\u5927\u5BB4\u4F1A\uFF01~ https:\/\/t.co\/DzfXXKVdeV @YouTube\u3055\u3093\u304B\u3089 https:\/\/t.co\/VmEfWyjjtJ",
    "id" : 1058644242837323776,
    "created_at" : "2018-11-03 08:57:10 +0000",
    "user" : {
      "name" : "\u96C5\u307E\u3064\u308A@ \uD83D\uDC9C\u2764\uFE0F\uD83D\uDC9B\uD83D\uDC99\uD83D\uDC96",
      "screen_name" : "magical_matsuri",
      "protected" : false,
      "id_str" : "966847939829092352",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1101157194613972992\/H5dtiyK7_normal.jpg",
      "id" : 966847939829092352,
      "verified" : false
    }
  },
  "id" : 1058679274465456128,
  "created_at" : "2018-11-03 11:16:22 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058386340943785986",
  "text" : "\u9593\u9055\u3048\u3066\u30EA\u30C4\u30A4\u30FC\u30C8\u3092\u524A\u9664\u3057\u305F\uD83D\uDCA6\n\u3068\u308A\u3042\u3048\u305A\u3082\u4E00\u5EA6\u30EA\u30C4\u30A4\u30FC\u30C8\u3059\u308B\n\u3082\u3046\u751F\u653E\u9001\u7D42\u308F\u308A\u306E\u30C4\u30A4\u30FC\u30C8\u306F\u300C\u3044\u3044\u306D\u300D\u3059\u308B",
  "id" : 1058386340943785986,
  "created_at" : "2018-11-02 15:52:22 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ {
      "name" : "\u3048\u3082\u3053\uD83C\uDFA8VTuber",
      "screen_name" : "emoco_art",
      "indices" : [ 3, 13 ],
      "id_str" : "968380144133001221",
      "id" : 968380144133001221
    } ],
    "media" : [ ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058382357844000768",
  "text" : "RT @emoco_art: \u304A\u83D3\u5B50\u306E\u5BB6\u3092\u3001STYLY\u306E\u65B0\u6A5F\u80FD\u300CVR Editor\u300D\u3067\u4F5C\u3063\u3066\u307F\u307E\u3057\u305F\uD83C\uDF6D\u2728\n\nVR\u7A7A\u9593\u3092\u81EA\u5206\u306E\u624B\u3067\u30B5\u30AF\u30B5\u30AF\u7DE8\u96C6\u3067\u304D\u3066\u3001\u3068\u3063\u3066\u3082\u697D\u3057\u3044\u3067\u3059\uD83D\uDE0D\n\n\u52D5\u753B\u3067\u4F7F\u3044\u65B9\u3092\u89E3\u8AAC\u3057\u3066\u308B\u306E\u3067\u3001\u305C\u3072\u4F7F\u3063\u3066\u307F\u3066\u304F\u3060\u3055\u3044\u263A\uFE0F\n\n\u2B07\uFE0F\u52D5\u753B\u306F\u3053\u3061\u3089\u2B07\uFE0F\nhttps:\/\/t.co\u2026",
  "retweeted_status" : {
    "source" : "\u003Ca href=\"http:\/\/twitter.com\/download\/iphone\" rel=\"nofollow\"\u003ETwitter for iPhone\u003C\/a\u003E",
    "entities" : {
      "user_mentions" : [ ],
      "media" : [ {
        "expanded_url" : "https:\/\/twitter.com\/emoco_art\/status\/1056833255217881089\/video\/1",
        "indices" : [ 183, 206 ],
        "url" : "https:\/\/t.co\/g1xBk7pHzg",
        "media_url" : "http:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1056833111277764608\/pu\/img\/YfOshn-hbKYVv7wU.jpg",
        "id_str" : "1056833111277764608",
        "id" : 1056833111277764608,
        "media_url_https" : "https:\/\/pbs.twimg.com\/ext_tw_video_thumb\/1056833111277764608\/pu\/img\/YfOshn-hbKYVv7wU.jpg",
        "sizes" : [ {
          "h" : 150,
          "resize" : "crop",
          "w" : 150
        }, {
          "h" : 675,
          "resize" : "fit",
          "w" : 1200
        }, {
          "h" : 383,
          "resize" : "fit",
          "w" : 680
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        }, {
          "h" : 720,
          "resize" : "fit",
          "w" : 1280
        } ],
        "media_alt" : "",
        "display_url" : "pic.twitter.com\/g1xBk7pHzg"
      } ],
      "hashtags" : [ {
        "text" : "STYLY",
        "indices" : [ 176, 182 ]
      } ],
      "urls" : [ {
        "indices" : [ 112, 135 ],
        "url" : "https:\/\/t.co\/JJQLNNbOf9",
        "expanded_url" : "https:\/\/youtu.be\/3rz2aH_JQwQ",
        "display_url" : "youtu.be\/3rz2aH_JQwQ"
      }, {
        "indices" : [ 151, 174 ],
        "url" : "https:\/\/t.co\/jBnZrlWBOg",
        "expanded_url" : "https:\/\/styly.cc\/",
        "display_url" : "styly.cc"
      } ]
    },
    "geo" : { },
    "id_str" : "1056833255217881089",
    "text" : "\u304A\u83D3\u5B50\u306E\u5BB6\u3092\u3001STYLY\u306E\u65B0\u6A5F\u80FD\u300CVR Editor\u300D\u3067\u4F5C\u3063\u3066\u307F\u307E\u3057\u305F\uD83C\uDF6D\u2728\n\nVR\u7A7A\u9593\u3092\u81EA\u5206\u306E\u624B\u3067\u30B5\u30AF\u30B5\u30AF\u7DE8\u96C6\u3067\u304D\u3066\u3001\u3068\u3063\u3066\u3082\u697D\u3057\u3044\u3067\u3059\uD83D\uDE0D\n\n\u52D5\u753B\u3067\u4F7F\u3044\u65B9\u3092\u89E3\u8AAC\u3057\u3066\u308B\u306E\u3067\u3001\u305C\u3072\u4F7F\u3063\u3066\u307F\u3066\u304F\u3060\u3055\u3044\u263A\uFE0F\n\n\u2B07\uFE0F\u52D5\u753B\u306F\u3053\u3061\u3089\u2B07\uFE0F\nhttps:\/\/t.co\/JJQLNNbOf9\n\n\u2B07\uFE0FSTYLY\u306F\u3053\u3061\u3089\u2B07\uFE0F\nhttps:\/\/t.co\/jBnZrlWBOg\n\n#STYLY https:\/\/t.co\/g1xBk7pHzg",
    "id" : 1056833255217881089,
    "created_at" : "2018-10-29 09:00:57 +0000",
    "user" : {
      "name" : "\u3048\u3082\u3053\uD83C\uDFA8VTuber",
      "screen_name" : "emoco_art",
      "protected" : false,
      "id_str" : "968380144133001221",
      "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1029356855515131904\/osJgJdzV_normal.jpg",
      "id" : 968380144133001221,
      "verified" : false
    }
  },
  "id" : 1058382357844000768,
  "created_at" : "2018-11-02 15:36:32 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
}, {
  "source" : "\u003Ca href=\"http:\/\/twitter.com\" rel=\"nofollow\"\u003ETwitter Web Client\u003C\/a\u003E",
  "entities" : {
    "user_mentions" : [ ],
    "media" : [ {
      "expanded_url" : "https:\/\/twitter.com\/uid_null\/status\/1058025462817943552\/photo\/1",
      "indices" : [ 60, 83 ],
      "url" : "https:\/\/t.co\/8e0qaBWRL3",
      "media_url" : "http:\/\/pbs.twimg.com\/media\/Dq7bUsEVAAAcNHk.jpg",
      "id_str" : "1058024110951825408",
      "id" : 1058024110951825408,
      "media_url_https" : "https:\/\/pbs.twimg.com\/media\/Dq7bUsEVAAAcNHk.jpg",
      "sizes" : [ {
        "h" : 150,
        "resize" : "crop",
        "w" : 150
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      }, {
        "h" : 500,
        "resize" : "fit",
        "w" : 500
      } ],
      "media_alt" : "",
      "display_url" : "pic.twitter.com\/8e0qaBWRL3"
    } ],
    "hashtags" : [ ],
    "urls" : [ ]
  },
  "geo" : { },
  "id_str" : "1058025462817943552",
  "text" : "\u3061\u3087\u3063\u3069\u3060\u3051\u304A\u7D75\u63CF\u304D\u3092\u3057\u306A\u3044\n\u3069\u3046\u898B\u3066\u308B\u306F\u5909\u306A\u611F\u3058\u304C\u3057\u3066\u3044\u308B\n\u7D39\u4ECB\u7528\u30E2\u30C7\u30EB\u3092\u4F5C\u308B\u3057\u305F\u3044\u3051\u3069\n\u3082\u3046\u5C11\u3057\u7DF4\u7FD2\u3059\u308B\u307B\u3046\u304C\u3044\u3044 https:\/\/t.co\/8e0qaBWRL3",
  "id" : 1058025462817943552,
  "created_at" : "2018-11-01 15:58:22 +0000",
  "user" : {
    "name" : "\uFF3F\uFF3F",
    "screen_name" : "uid_null",
    "protected" : false,
    "id_str" : "1050640493871153152",
    "profile_image_url_https" : "https:\/\/pbs.twimg.com\/profile_images\/1097215512369496064\/m98RkBpM_normal.png",
    "id" : 1050640493871153152,
    "verified" : false
  }
} ]