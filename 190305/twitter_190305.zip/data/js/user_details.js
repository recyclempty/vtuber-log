var user_details =  {
  "screen_name" : "uid_null",
  "location" : "\u570F\u5916",
  "full_name" : "\uFF3F\uFF3F",
  "bio" : "9E4EF62E866E4EA6CE46F204A6CE4EA66E962E36AEB2",
  "id" : "1050640493871153152",
  "created_at" : "2018-10-12 06:53:08 +0000"
}